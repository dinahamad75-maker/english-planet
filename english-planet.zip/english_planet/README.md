# English Planet – كوكب التأسيس

**Start Small. Learn Big.**

تطبيق أندرويد لتعلّم الإنجليزية من الصفر، بالعربي (RTL) والإنجليزي، مبني بـ Flutter.

A bilingual (Arabic RTL / English) Android app for learning English from scratch, built with Flutter.

---

## What's inside / المحتوى

- **Onboarding** (3 خطوات): ترحيب، اختيار اللغة (عربي/English)، اختيار المستوى (مبتدئ تمامًا / أساسيات / متوسط).
- **Home**: تحية باسم المستخدمة، streak، هدف يومي، كارت "كمّلي من حيث وقفتي"، مسارات التعلم، ودروس مقترحة.
- **Learning paths** (6 مسارات مرتبة حسب CEFR: A1 → B1) — مثال: "البداية الصح"، "قواعد أساسية"، "محادثات يومية".
- **Grammar**: 6 دروس كاملة بشرح عربي واضح وأمثلة: Verb To Be, Articles, Present Simple, Present Continuous, Past Simple, Present Perfect — كل درس فيه اختبار تفاعلي مع نتيجة وأوسمة.
- **Vocabulary**: 4 مواضيع (الحياة اليومية، العيلة، الأكل، السفر) بكلمات + نطق + مثال، مع حفظ المفضلة ❤️.
- **Phonics**: الحروف والأصوات، تركيز كبير على الحروف المتحركة (قصير vs طويل، القواعد، أمثلة كتير لكل صوت، وتدريب minimal pairs)، بالإضافة للتجمعات والأصوات المركبة والحروف الساكنة.
- **Conversations**: 4 محادثات يومية حقيقية (تعارف، في المطعم، سؤال عن الطريق، في الشغل) مع ترجمة سطر بسطر.
- **Progress**: streak، دروس مكتملة، نتائج الاختبارات، أوسمة (7 أوسمة)، الكلمات المفضلة.
- **Profile/Settings**: اسم، لغة التطبيق، مستوى، هدف يومي، وضع ليلي، إعادة ضبط.
- **Search**: بحث شامل في الدروس والكلمات والمحادثات.
- **النطق (TTS)**: زرار سماعة جنب كل كلمة وجملة (يشتغل على الجهاز؛ غير متاح في المتصفح).

## Brand / الهوية

Navy `#172B4D` • Sky `#49B7E9` • Yellow `#FFC94A` • Off-white `#F7FAFC` • Coral `#FF817A`
Rounded cards, soft shadows, planet mascot 🪐, Arabic-first RTL, adult-friendly.

## Tech

- Flutter 3.50 (Dart 3), Material 3, custom theme, no external UI packages.
- State: lightweight `ChangeNotifier` + `SharedPreferences` persistence (guest mode, no backend yet).
- `flutter_tts` for pronunciation on device.

## Build the APK / بناء ملف التثبيت

The sandbox where this was written could not run the Android Gradle build (out of memory), so the APK is built locally:

```bash
# 1) Install Flutter 3.50+ and the Android SDK (Android Studio), then:
flutter pub get
flutter build apk --release        # build/app/outputs/flutter-apk/app-release.apk
# or a split, smaller set:
flutter build apk --release --split-per-abi
```

Requirements: ~4 GB+ free RAM for Gradle, Android SDK 34, JDK 17 (bundled with recent Android Studio).

To change the app id before publishing, edit `applicationId` in `android/app/build.gradle.kts` (currently `com.dina.englishplanet`).

## Verify / التحقق

```bash
flutter analyze    # 0 errors (only deprecation infos from Flutter 3.50 itself)
flutter test       # widget tests: splash → onboarding → main shell
```

## Roadmap (غير مُنفّذ بعد)

- Firebase (auth, sync, analytics) — الكود معمول بشكل يفصل المحتوى عن المنطق تسهيلًا لذلك.
- Payment / freemium unlock.
- Play Store listing assets.
- More lessons per level (content separated in `lib/content/` for easy expansion).

---

© English Planet — Phase 1 source deliverable.
