package com.dina.englishplanet

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
