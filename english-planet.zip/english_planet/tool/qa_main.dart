import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:english_planet/content/conversations.dart';
import 'package:english_planet/content/grammar.dart';
import 'package:english_planet/content/paths.dart';
import 'package:english_planet/content/phonics.dart';
import 'package:english_planet/content/vocabulary.dart';
import 'package:english_planet/screens/conversations_screen.dart';
import 'package:english_planet/screens/grammar_screen.dart';
import 'package:english_planet/screens/home_screen.dart';
import 'package:english_planet/screens/lesson_screen.dart';
import 'package:english_planet/screens/main_shell.dart';
import 'package:english_planet/screens/onboarding_screen.dart';
import 'package:english_planet/screens/path_detail_screen.dart';
import 'package:english_planet/screens/paths_screen.dart';
import 'package:english_planet/screens/phonics_screen.dart';
import 'package:english_planet/screens/profile_screen.dart';
import 'package:english_planet/screens/progress_screen.dart';
import 'package:english_planet/screens/quiz_screen.dart';
import 'package:english_planet/screens/search_screen.dart';
import 'package:english_planet/screens/skills_screen.dart';
import 'package:english_planet/screens/vocabulary_screen.dart';
import 'package:english_planet/state/app_state.dart';
import 'package:english_planet/theme/app_theme.dart';

/// QA harness: `flutter build web -t tool/qa_main.dart`, then open
/// `?screen=home|onboarding|paths|pathdetail|skills|grammar|vocabulary|
/// topic|phonics|conversations|convo|lesson|quiz|progress|profile|search`
/// to render one screen directly for headless screenshots.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final String screen = Uri.base.queryParameters['screen'] ?? 'home';

  final Widget target = switch (screen) {
    'onboarding' => const OnboardingScreen(),
    'home' => const MainShell(),
    'paths' => const PathsScreen(),
    'pathdetail' => PathDetailScreen(path: learningPaths.first),
    'skills' => const SkillsScreen(),
    'grammar' => const GrammarScreen(),
    'vocabulary' => const VocabularyScreen(),
    'topic' => TopicWordsScreen(topic: vocabTopics.first),
    'phonics' => const PhonicsScreen(),
    'vowelrules' =>
        PhonicsSectionScreen(section: phonicsById('p-vowel-rules')!),
    'vowela' => PhonicsSectionScreen(section: phonicsById('p-vowel-a')!),
    'conversations' => const ConversationsScreen(),
    'convo' => ConversationDetailScreen(conversation: conversations.first),
    'lesson' => LessonScreen(lesson: grammarLessons.first),
    'quiz' => QuizScreen(lesson: grammarLessons.first),
    'progress' => const ProgressScreen(),
    'profile' => const ProfileScreen(),
    'search' => const SearchScreen(),
    _ => const MainShell(),
  };

  runApp(
    ListenableBuilder(
      listenable: appState,
      builder: (BuildContext context, _) {
        return MaterialApp(
          title: 'English Planet QA',
          debugShowCheckedModeBanner: false,
          locale: appState.locale,
          supportedLocales: const <Locale>[Locale('ar'), Locale('en')],
          localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: AppTheme.light(),
          darkTheme: AppTheme.dark(),
          themeMode: appState.darkMode ? ThemeMode.dark : ThemeMode.light,
          home: target,
        );
      },
    ),
  );
}
