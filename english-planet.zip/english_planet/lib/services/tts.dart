import 'package:flutter_tts/flutter_tts.dart';

/// Thin wrapper around the device text-to-speech engine, used to pronounce
/// English words, letters and sentences. Works fully offline with the
/// device's built-in TTS data.
class TtsService {
  TtsService._();
  static final TtsService instance = TtsService._();

  final FlutterTts _tts = FlutterTts();
  bool _ready = false;

  Future<void> _ensureReady() async {
    if (_ready) return;
    try {
      await _tts.setLanguage('en-US');
      await _tts.setSpeechRate(0.42);
      await _tts.setPitch(1.0);
      _ready = true;
    } catch (_) {
      // TTS unavailable on this device; speaking will simply no-op.
    }
  }

  Future<void> speak(String text) async {
    try {
      await _ensureReady();
      await _tts.stop();
      await _tts.speak(text);
    } catch (_) {
      // Ignore: pronunciation is a convenience, never a crash.
    }
  }

  Future<void> dispose() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
