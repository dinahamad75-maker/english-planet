import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Global application state: preferences, progress, streaks and favorites.
/// Persisted locally with SharedPreferences (offline-first; no backend yet).
final AppState appState = AppState();

class AppState extends ChangeNotifier {
  // ---- preferences ----
  Locale locale = const Locale('ar');
  bool darkMode = false;
  bool onboarded = false;
  String level = 'Pre-A1';
  String userName = '';
  int dailyGoal = 2; // lessons per day

  // ---- progress ----
  final Set<String> completedLessons = {};
  final Set<String> favoriteWords = {};
  final Map<String, int> quizBest = {}; // quizId -> best score in percent
  int streak = 0;
  String lastActiveDay = '';
  int lessonsToday = 0;
  String countersDay = '';

  static const List<String> levels = <String>[
    'Pre-A1', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2',
  ];

  bool get isAr => locale.languageCode == 'ar';

  String _today() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  // ---------- loading / saving ----------

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    locale = Locale(prefs.getString('locale') ?? 'ar');
    darkMode = prefs.getBool('darkMode') ?? false;
    onboarded = prefs.getBool('onboarded') ?? false;
    level = prefs.getString('level') ?? 'Pre-A1';
    userName = prefs.getString('userName') ?? '';
    dailyGoal = prefs.getInt('dailyGoal') ?? 2;
    streak = prefs.getInt('streak') ?? 0;
    lastActiveDay = prefs.getString('lastActiveDay') ?? '';
    lessonsToday = prefs.getInt('lessonsToday') ?? 0;
    countersDay = prefs.getString('countersDay') ?? '';
    completedLessons
      ..clear()
      ..addAll((jsonDecode(prefs.getString('completedLessons') ?? '[]') as List).cast<String>());
    favoriteWords
      ..clear()
      ..addAll((jsonDecode(prefs.getString('favoriteWords') ?? '[]') as List).cast<String>());
    quizBest
      ..clear()
      ..addAll((jsonDecode(prefs.getString('quizBest') ?? '{}') as Map).map(
        (k, v) => MapEntry(k as String, (v as num).toInt()),
      ));
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale', locale.languageCode);
    await prefs.setBool('darkMode', darkMode);
    await prefs.setBool('onboarded', onboarded);
    await prefs.setString('level', level);
    await prefs.setString('userName', userName);
    await prefs.setInt('dailyGoal', dailyGoal);
    await prefs.setInt('streak', streak);
    await prefs.setString('lastActiveDay', lastActiveDay);
    await prefs.setInt('lessonsToday', lessonsToday);
    await prefs.setString('countersDay', countersDay);
    await prefs.setString('completedLessons', jsonEncode(completedLessons.toList()));
    await prefs.setString('favoriteWords', jsonEncode(favoriteWords.toList()));
    await prefs.setString('quizBest', jsonEncode(quizBest));
  }

  // ---------- preference setters ----------

  void setLocale(String code) {
    locale = Locale(code);
    notifyListeners();
    _save();
  }

  void setDarkMode(bool value) {
    darkMode = value;
    notifyListeners();
    _save();
  }

  void setLevel(String value) {
    level = value;
    notifyListeners();
    _save();
  }

  void setUserName(String value) {
    userName = value.trim();
    notifyListeners();
    _save();
  }

  void setDailyGoal(int value) {
    dailyGoal = value;
    notifyListeners();
    _save();
  }

  Future<void> completeOnboarding() async {
    onboarded = true;
    notifyListeners();
    await _save();
  }

  // ---------- progress ----------

  /// Called when the home screen opens: rolls the daily counters and streak.
  void touchActivity() {
    final today = _today();
    if (countersDay != today) {
      countersDay = today;
      lessonsToday = 0;
    }
    if (lastActiveDay != today) {
      final yesterday = DateTime.now().subtract(const Duration(days: 1));
      final y = '${yesterday.year}-${yesterday.month.toString().padLeft(2, '0')}-${yesterday.day.toString().padLeft(2, '0')}';
      streak = (lastActiveDay == y) ? streak + 1 : 1;
      lastActiveDay = today;
    }
    notifyListeners();
    _save();
  }

  bool isLessonDone(String id) => completedLessons.contains(id);

  void completeLesson(String id) {
    if (completedLessons.add(id)) {
      if (countersDay != _today()) {
        countersDay = _today();
        lessonsToday = 0;
      }
      lessonsToday += 1;
      notifyListeners();
      _save();
    }
  }

  void recordQuizScore(String quizId, int percent) {
    final best = quizBest[quizId] ?? -1;
    if (percent > best) {
      quizBest[quizId] = percent;
      notifyListeners();
      _save();
    }
  }

  int? quizScore(String quizId) => quizBest[quizId];

  bool isFavorite(String wordKey) => favoriteWords.contains(wordKey);

  void toggleFavorite(String wordKey) {
    if (!favoriteWords.remove(wordKey)) {
      favoriteWords.add(wordKey);
    }
    notifyListeners();
    _save();
  }

  double get dailyGoalProgress =>
      dailyGoal == 0 ? 0 : (lessonsToday / dailyGoal).clamp(0.0, 1.0);

  List<AppBadge> get earnedBadges {
    final badges = <AppBadge>[];
    final done = completedLessons.length;
    final perfect = quizBest.values.where((s) => s == 100).length;
    if (done >= 1) badges.add(AppBadge.firstLesson);
    if (done >= 5) badges.add(AppBadge.fiveLessons);
    if (done >= 10) badges.add(AppBadge.tenLessons);
    if (streak >= 3) badges.add(AppBadge.streak3);
    if (streak >= 7) badges.add(AppBadge.streak7);
    if (perfect >= 1) badges.add(AppBadge.perfectQuiz);
    if (favoriteWords.length >= 10) badges.add(AppBadge.collector);
    return badges;
  }

  Future<void> resetAll() async {
    completedLessons.clear();
    favoriteWords.clear();
    quizBest.clear();
    streak = 0;
    lastActiveDay = '';
    lessonsToday = 0;
    countersDay = '';
    notifyListeners();
    await _save();
  }
}

enum AppBadge {
  firstLesson,
  fiveLessons,
  tenLessons,
  streak3,
  streak7,
  perfectQuiz,
  collector,
}
