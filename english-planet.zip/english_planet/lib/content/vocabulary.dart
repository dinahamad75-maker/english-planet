import '../models/models.dart';
import 'vocabulary_part1.dart';
import 'vocabulary_part2.dart';

/// Vocabulary topics: curated, accurate word lists with phonetics and
/// bilingual example sentences.
final List<VocabTopic> vocabTopics = <VocabTopic>[
  ...vocabTopicsPart1,
  ...vocabTopicsPart2,
];

VocabTopic? vocabTopicById(String id) {
  for (final VocabTopic t in vocabTopics) {
    if (t.id == id) return t;
  }
  return null;
}
