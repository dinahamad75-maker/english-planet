import 'package:flutter/material.dart';

import '../models/models.dart';
import '../theme/app_theme.dart';

/// Vocabulary topics, part 2: Food, Travel.
final List<VocabTopic> vocabTopicsPart2 = <VocabTopic>[_food, _travel];

const VocabTopic _food = VocabTopic(
  id: 'v-food',
  titleAr: 'الطعام',
  titleEn: 'Food',
  icon: Icons.restaurant_rounded,
  color: AppColors.yellow,
  words: <VocabWord>[
    VocabWord(
      en: 'bread',
      ar: 'خبز / عيش',
      phonetic: '/bred/',
      exampleEn: 'We buy fresh bread every day.',
      exampleAr: 'بنشتري عيش طازة كل يوم.'),
    VocabWord(
      en: 'rice',
      ar: 'أرز',
      phonetic: '/raɪs/',
      exampleEn: 'She cooks rice with vegetables.',
      exampleAr: 'هي بتطبخ أرز بالخضار.'),
    VocabWord(
      en: 'chicken',
      ar: 'دجاج / فراخ',
      phonetic: '/ˈtʃɪkɪn/',
      exampleEn: 'We eat chicken for lunch on Fridays.',
      exampleAr: 'بناكل فراخ في الغدا يوم الجمعة.'),
    VocabWord(
      en: 'cheese',
      ar: 'جبنة',
      phonetic: '/tʃiːz/',
      exampleEn: 'I like cheese with my breakfast.',
      exampleAr: 'بحب الجبنة في الفطار.'),
    VocabWord(
      en: 'milk',
      ar: 'لبن / حليب',
      phonetic: '/mɪlk/',
      exampleEn: 'The baby drinks milk every night.',
      exampleAr: 'البيبي بيشرب لبن كل ليلة.'),
    VocabWord(
      en: 'apple',
      ar: 'تفاحة',
      phonetic: '/ˈæpl/',
      exampleEn: 'An apple a day keeps the doctor away.',
      exampleAr: 'تفاحة في اليوم بتغنيك عن الدكتور (مثل شهير).'),
    VocabWord(
      en: 'water',
      ar: 'مية',
      phonetic: '/ˈwɔːtər/',
      exampleEn: 'Drink eight glasses of water a day.',
      exampleAr: 'اشرب تمان كوبايات مية في اليوم.'),
    VocabWord(
      en: 'tea',
      ar: 'شاي',
      phonetic: '/tiː/',
      exampleEn: 'Would you like a cup of tea?',
      exampleAr: 'تحب كوباية شاي؟'),
    VocabWord(
      en: 'meat',
      ar: 'لحمة',
      phonetic: '/miːt/',
      exampleEn: 'They eat meat twice a week.',
      exampleAr: 'هم بياكلوا لحمة مرتين في الأسبوع.'),
    VocabWord(
      en: 'fruit',
      ar: 'فاكهة',
      phonetic: '/fruːt/',
      exampleEn: 'Fruit is good for your health.',
      exampleAr: 'الفاكهة مفيدة لصحتك.'),
  ],
);

const VocabTopic _travel = VocabTopic(
  id: 'v-travel',
  titleAr: 'السفر',
  titleEn: 'Travel',
  icon: Icons.flight_rounded,
  color: AppColors.mint,
  words: <VocabWord>[
    VocabWord(
      en: 'airport',
      ar: 'مطار',
      phonetic: '/ˈerpɔːrt/',
      exampleEn: 'We arrived at the airport early.',
      exampleAr: 'وصلنا المطار بدري.'),
    VocabWord(
      en: 'ticket',
      ar: 'تذكرة',
      phonetic: '/ˈtɪkɪt/',
      exampleEn: 'I bought my ticket online.',
      exampleAr: 'اشتريت التذكرة أونلاين.'),
    VocabWord(
      en: 'passport',
      ar: 'جواز سفر',
      phonetic: '/ˈpæspɔːrt/',
      exampleEn: 'Don\'t forget your passport!',
      exampleAr: 'متنساش جواز السفر!'),
    VocabWord(
      en: 'luggage',
      ar: 'شنط السفر / أمتعة',
      phonetic: '/ˈlʌɡɪdʒ/',
      exampleEn: 'Our luggage is very heavy.',
      exampleAr: 'شنطنا تقيلة جدًا.'),
    VocabWord(
      en: 'hotel',
      ar: 'فندق',
      phonetic: '/hoʊˈtel/',
      exampleEn: 'The hotel has a big swimming pool.',
      exampleAr: 'الفندق فيه حمام سباحة كبير.'),
    VocabWord(
      en: 'beach',
      ar: 'شاطئ',
      phonetic: '/biːtʃ/',
      exampleEn: 'We swam at the beach all morning.',
      exampleAr: 'عومنا على الشاطئ طول الصبح.'),
    VocabWord(
      en: 'train',
      ar: 'قطار',
      phonetic: '/treɪn/',
      exampleEn: 'The train to Cairo leaves at nine.',
      exampleAr: 'قطار القاهرة بيقوم الساعة تسعة.'),
    VocabWord(
      en: 'map',
      ar: 'خريطة',
      phonetic: '/mæp/',
      exampleEn: 'Let\'s look at the map first.',
      exampleAr: 'خلينا نشوف الخريطة الأول.'),
    VocabWord(
      en: 'trip',
      ar: 'رحلة',
      phonetic: '/trɪp/',
      exampleEn: 'Our trip to Aswan was amazing.',
      exampleAr: 'رحلتنا لأسوان كانت جميلة جدًا.'),
    VocabWord(
      en: 'visa',
      ar: 'تأشيرة / فيزا',
      phonetic: '/ˈviːzə/',
      exampleEn: 'You need a visa to visit some countries.',
      exampleAr: 'محتاج تأشيرة عشان تزور بعض الدول.'),
  ],
);
