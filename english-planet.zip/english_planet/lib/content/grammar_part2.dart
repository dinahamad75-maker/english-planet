import '../models/models.dart';

/// Grammar lessons, part 2: Present Simple, Present Continuous.
final List<Lesson> grammarLessonsPart2 = <Lesson>[_presentSimple, _presentContinuous];

const Lesson _presentSimple = Lesson(
  id: 'g-present-simple',
  titleEn: 'Present Simple',
  titleAr: 'المضارع البسيط',
  level: 'A1',
  minutes: 10,
  introAr:
      'المضارع البسيط هو زمن العادات والحقائق: حاجات بتحصل كل يوم، أو حقائق ثابتة زي "الشمس بتشرق من الشرق".',
  explanationAr: <String>[
    'بنستخدم المضارع البسيط للعادات (I wake up at 7) والحقائق (Water boils at 100 degrees) والجداول الثابتة (The train leaves at 9).',
    'مع الفاعل المفرد الغائب (he / she / it) بنضيف s للفعل: he plays, she works, it rains. دي أهم قاعدة في الزمن ده.',
    'للنفي بنستخدم don\'t مع I/you/we/they وdoesn\'t مع he/she/it، وبعد doesn\'t الفعل بيرجع لصورته الأصلية بدون s.',
    'للسؤال بنستخدم Do في الأول مع I/you/we/they وDoes مع he/she/it: Do you like tea? Does she play tennis?',
  ],
  examples: <LessonExample>[
    LessonExample('I drink coffee every morning.', 'بشرب قهوة كل صباح.'),
    LessonExample('She works in a bank.', 'هي بتشتغل في بنك.'),
    LessonExample('They don\'t watch TV at night.', 'هم مبيتفرجوش على التلفزيون بالليل.'),
    LessonExample('Does he play football? Yes, he does.', 'هل هو بيلعب كورة؟ أيوه.'),
    LessonExample('The sun rises in the east.', 'الشمس بتشرق من الشرق.'),
  ],
  notesAr: <String>[
    'الكلمات الدالة عليه: always, usually, often, sometimes, never, every day/week.',
    'بعد doesn\'t وdoes الفعل مبيرجعش ياخد s: نقول Does she play? مش Does she plays?',
    'الأفعال اللي بتنتهي بـ o, ch, sh, ss, x بنضيفلها es: go→goes, watch→watches.',
  ],
  mistakes: <CommonMistake>[
    CommonMistake('She go to school.', 'She goes to school.', 'مع she لازم نضيف s (وهنا es لأن go بتاخد es).'),
    CommonMistake('Does he likes tea?', 'Does he like tea?', 'بعد Does الفعل بيرجع أصله بدون s.'),
    CommonMistake('I am play football every day.', 'I play football every day.', 'المضارع البسيط للعادات مبياخدش am/is/are.'),
  ],
  quiz: <QuizQuestion>[
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: 'He ___ to work by bus.',
      options: <String>['go', 'goes', 'going', 'is go'],
      answerIndex: 1,
      explanationAr: 'مع he بنضيف es للفعل go فتصبح goes.',
    ),
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: '___ you speak English?',
      options: <String>['Does', 'Do', 'Is', 'Are'],
      answerIndex: 1,
      explanationAr: 'مع you في السؤال بنستخدم Do.',
    ),
    QuizQuestion(
      type: QuestionType.trueFalse,
      promptAr: 'صح ولا غلط؟',
      promptEn: 'She doesn\'t likes fish.',
      answerIndex: 1,
      explanationAr: 'غلط. بعد doesn\'t الفعل بدون s: She doesn\'t like fish.',
    ),
    QuizQuestion(
      type: QuestionType.fillBlank,
      promptAr: 'أكمل الجملة:',
      promptEn: 'They ___ TV every evening. (watch)',
      options: <String>['watches', 'watch', 'watching', 'are watch'],
      answerIndex: 1,
      explanationAr: 'they جمع، فالفعل يفضل في صورته الأصلية: watch.',
    ),
    QuizQuestion(
      type: QuestionType.arrange,
      promptAr: 'رتّب الكلمات لتكوين سؤال صحيح:',
      options: <String>['Does', 'play', 'she', 'tennis'],
      arrangeAnswer: <String>['Does', 'she', 'play', 'tennis'],
      explanationAr: 'السؤال في المضارع البسيط: Does + الفاعل + الفعل الأصلي.',
    ),
  ],
);

const Lesson _presentContinuous = Lesson(
  id: 'g-present-continuous',
  titleEn: 'Present Continuous',
  titleAr: 'المضارع المستمر',
  level: 'A1',
  minutes: 10,
  introAr:
      'المضارع المستمر بنستخدمه لحاجة بتحصل دلوقتي بالظبط، في اللحظة دي: أنا بذاكر دلوقتي، هو بياكل حاليًا.',
  explanationAr: <String>[
    'تكوينه: am/is/are + الفعل مضافًا له ing. مثال: I am studying. She is cooking. They are playing.',
    'بنستخدمه للأحداث الجارية الآن (Look! It is raining) وللمواقف المؤقتة (I am staying with a friend this week) وأحيانًا لترتيبات قريبة مؤكدة (We are meeting Ahmed tomorrow).',
    'للنفي بنضيف not بعد am/is/are: She is not sleeping. وللسؤال نقدّم am/is/are: Are you listening?',
    'أفعال الإحساس والرأي والملكية زي like, love, know, want, need مبتستخدمش المستمر عادة: نقول I like tea مش I am liking tea.',
  ],
  examples: <LessonExample>[
    LessonExample('I am studying English now.', 'أنا بذاكر إنجليزي دلوقتي.'),
    LessonExample('Look! The baby is crying.', 'بصّ! الطفل بيعيط.'),
    LessonExample('They are not watching TV.', 'هم مش بيتفرجوا على التلفزيون دلوقتي.'),
    LessonExample('Is she cooking dinner? Yes, she is.', 'هل هي بتطبخ العشا؟ أيوه.'),
    LessonExample('We are staying at a hotel this week.', 'إحنا قاعدين في فندق الأسبوع ده (مؤقتًا).'),
  ],
  notesAr: <String>[
    'الكلمات الدالة عليه: now, right now, at the moment, Look!, Listen!',
    'أفعال زي write وmake بنشيل الـ e قبل إضافة ing: writing, making.',
    'أفعال زي sit وrun بنضاعف الحرف الأخير: sitting, running.',
  ],
  mistakes: <CommonMistake>[
    CommonMistake('She playing now.', 'She is playing now.', 'المضارع المستمر محتاج is/am/are قبل الفعل مع ing.'),
    CommonMistake('I am knowing the answer.', 'I know the answer.', 'know من أفعال الإدراك اللي مبتاخدش المستمر.'),
    CommonMistake('He is writeing a letter.', 'He is writing a letter.', 'بنشيل الـ e من write قبل إضافة ing.'),
  ],
  quiz: <QuizQuestion>[
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: 'Listen! Someone ___ the door.',
      options: <String>['opens', 'is opening', 'open', 'opening'],
      answerIndex: 1,
      explanationAr: 'Listen! كلمة دالة على المستمر: is opening.',
    ),
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: 'They ___ football in the park now.',
      options: <String>['plays', 'is playing', 'are playing', 'play'],
      answerIndex: 2,
      explanationAr: 'they بياخد are: They are playing.',
    ),
    QuizQuestion(
      type: QuestionType.trueFalse,
      promptAr: 'صح ولا غلط؟',
      promptEn: 'I am liking this song.',
      answerIndex: 1,
      explanationAr: 'غلط. like من أفعال الإحساس: I like this song.',
    ),
    QuizQuestion(
      type: QuestionType.fillBlank,
      promptAr: 'أكمل الجملة:',
      promptEn: 'She is ___ a book at the moment. (read)',
      options: <String>['read', 'reads', 'reading', 'readed'],
      answerIndex: 2,
      explanationAr: 'بعد is نستخدم الفعل + ing: reading.',
    ),
    QuizQuestion(
      type: QuestionType.arrange,
      promptAr: 'رتّب الكلمات لتكوين جملة صحيحة:',
      options: <String>['am', 'I', 'now', 'studying'],
      arrangeAnswer: <String>['I', 'am', 'studying', 'now'],
      explanationAr: 'I + am + studying: مضارع مستمر سليم.',
    ),
  ],
);
