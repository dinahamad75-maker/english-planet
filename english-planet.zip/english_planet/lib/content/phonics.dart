import '../models/models.dart';
import 'phonics_part1.dart';
import 'phonics_part2.dart';
import 'phonics_part3.dart';

/// Phonics and reading sections, for tap-to-hear practice with the device
/// text-to-speech engine.
final List<PhonicsSection> phonicsSections = <PhonicsSection>[
  ...phonicsSectionsPart1,
  ...phonicsSectionsPart2,
  ...phonicsSectionsPart3,
];

PhonicsSection? phonicsById(String id) {
  for (final PhonicsSection s in phonicsSections) {
    if (s.id == id) return s;
  }
  return null;
}
