import 'package:flutter/material.dart';

import '../models/models.dart';
import '../theme/app_theme.dart';

/// CEFR learning paths. Each path is an ordered sequence of references to
/// real content items, so paths grow as the content library grows.
final List<LearningPath> learningPaths = <LearningPath>[
  const LearningPath(
    id: 'path-foundation',
    titleAr: 'التأسيس الكامل',
    titleEn: 'Complete English Foundation',
    cefr: 'Pre-A1',
    descAr: 'ابدأ من الصفر: الحروف والأصوات، أهم الكلمات، وأول قواعد اللغة.',
    color: AppColors.sky,
    icon: Icons.rocket_launch_rounded,
    items: <PathItem>[
      PathItem(PathItemKind.phonics, 'p-alphabet'),
      PathItem(PathItemKind.phonics, 'p-short-vowels'),
      PathItem(PathItemKind.phonics, 'p-cvc'),
      PathItem(PathItemKind.vocabulary, 'v-family'),
      PathItem(PathItemKind.grammar, 'g-verb-to-be'),
    ],
  ),
  const LearningPath(
    id: 'path-beginner',
    titleAr: 'الإنجليزية للمبتدئين',
    titleEn: 'Beginner English',
    cefr: 'A1',
    descAr: 'ابنِ جملك الأولى بثقة: المضارع البسيط، الأدوات، وكلمات الحياة اليومية.',
    color: AppColors.mint,
    icon: Icons.eco_rounded,
    items: <PathItem>[
      PathItem(PathItemKind.vocabulary, 'v-daily-life'),
      PathItem(PathItemKind.grammar, 'g-articles'),
      PathItem(PathItemKind.grammar, 'g-present-simple'),
      PathItem(PathItemKind.grammar, 'g-present-continuous'),
      PathItem(PathItemKind.conversation, 'c-introductions'),
    ],
  ),
  const LearningPath(
    id: 'path-elementary',
    titleAr: 'المستوى الابتدائي',
    titleEn: 'Elementary English',
    cefr: 'A2',
    descAr: 'اتكلم عن الماضي ووسّع قاموسك: الطعام والسفر ومواقف حقيقية.',
    color: AppColors.yellow,
    icon: Icons.menu_book_rounded,
    items: <PathItem>[
      PathItem(PathItemKind.phonics, 'p-long-vowels'),
      PathItem(PathItemKind.grammar, 'g-past-simple'),
      PathItem(PathItemKind.vocabulary, 'v-food'),
      PathItem(PathItemKind.conversation, 'c-restaurant'),
      PathItem(PathItemKind.conversation, 'c-shopping'),
    ],
  ),
  const LearningPath(
    id: 'path-intermediate',
    titleAr: 'المستوى المتوسط',
    titleEn: 'Intermediate English',
    cefr: 'B1',
    descAr: 'اربط الماضي بالحاضر بالمضارع التام، وتدرّب على مواقف السفر.',
    color: AppColors.coral,
    icon: Icons.terrain_rounded,
    items: <PathItem>[
      PathItem(PathItemKind.phonics, 'p-blends'),
      PathItem(PathItemKind.grammar, 'g-present-perfect'),
      PathItem(PathItemKind.vocabulary, 'v-travel'),
      PathItem(PathItemKind.conversation, 'c-airport'),
    ],
  ),
  const LearningPath(
    id: 'path-upper-intermediate',
    titleAr: 'فوق المتوسط',
    titleEn: 'Upper Intermediate English',
    cefr: 'B2',
    descAr: 'قريبًا: قواعد متقدمة ومحادثات أعمق. هنضيف دروس المستوى ده في التحديث الجاي.',
    color: AppColors.navyLight,
    icon: Icons.trending_up_rounded,
    items: <PathItem>[
      PathItem(PathItemKind.phonics, 'p-digraphs'),
      PathItem(PathItemKind.phonics, 'p-silent'),
    ],
  ),
  const LearningPath(
    id: 'path-advanced',
    titleAr: 'المستوى المتقدم',
    titleEn: 'Advanced English',
    cefr: 'C1-C2',
    descAr: 'قريبًا: محتوى احترافي للمستويات المتقدمة. هنضيفه في التحديثات الجاية.',
    color: AppColors.navy,
    icon: Icons.workspace_premium_rounded,
    items: <PathItem>[
      PathItem(PathItemKind.phonics, 'p-sight-words'),
    ],
  ),
];

LearningPath? pathById(String id) {
  for (final LearningPath p in learningPaths) {
    if (p.id == id) return p;
  }
  return null;
}
