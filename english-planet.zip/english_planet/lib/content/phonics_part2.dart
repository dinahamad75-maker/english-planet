import '../models/models.dart';

/// Phonics and reading content, part 2: blends, digraphs, silent letters,
/// sight words.
final List<PhonicsSection> phonicsSectionsPart2 = <PhonicsSection>[
  _blends,
  _digraphs,
  _silentLetters,
  _sightWords,
];

const PhonicsSection _blends = PhonicsSection(
  id: 'p-blends',
  titleAr: 'تجمعات الحروف الساكنة',
  titleEn: 'Consonant Blends',
  items: <PhonicsItem>[
    PhonicsItem('bl', 'صوت "بل" متصل', 'blue', 'أزرق'),
    PhonicsItem('st', 'صوت "ست" متصل', 'star', 'نجمة'),
    PhonicsItem('tr', 'صوت "تر" متصل', 'tree', 'شجرة'),
    PhonicsItem('gr', 'صوت "جر" متصل', 'green', 'أخضر'),
    PhonicsItem('pl', 'صوت "بل" متصل', 'play', 'يلعب'),
    PhonicsItem('fr', 'صوت "فر" متصل', 'frog', 'ضفدع'),
  ],
);

const PhonicsSection _digraphs = PhonicsSection(
  id: 'p-digraphs',
  titleAr: 'الأصوات المركبة (Digraphs)',
  titleEn: 'Digraphs',
  items: <PhonicsItem>[
    PhonicsItem('sh', 'صوت "ش"', 'ship', 'مركب'),
    PhonicsItem('ch', 'صوت "تش"', 'chair', 'كرسي'),
    PhonicsItem('th', 'صوت "ث" أو "ذ" حسب الكلمة', 'three', 'تلاتة'),
    PhonicsItem('ph', 'صوت "ف"', 'phone', 'تليفون'),
    PhonicsItem('wh', 'صوت "و"', 'whale', 'حوت'),
    PhonicsItem('ck', 'صوت "ك" في آخر الكلمة', 'duck', 'بطة'),
  ],
);

const PhonicsSection _silentLetters = PhonicsSection(
  id: 'p-silent',
  titleAr: 'الحروف الساكنة',
  titleEn: 'Silent Letters',
  items: <PhonicsItem>[
    PhonicsItem('k + n', 'الـ k مش بتتنطق قبل n', 'knee', 'ركبة'),
    PhonicsItem('w + r', 'الـ w مش بتتنطق قبل r', 'write', 'يكتب'),
    PhonicsItem('b بعد m', 'الـ b ساكنة بعد m', 'lamb', 'خروف صغير'),
    PhonicsItem('gh', 'مركب gh ساكن في كلمات كتير', 'night', 'ليل'),
    PhonicsItem('h في البداية', 'الـ h ساكنة أحيانًا في أول الكلمة', 'hour', 'ساعة'),
    PhonicsItem('l', 'الـ l ساكنة في كلمات زي', 'talk', 'يتكلم'),
  ],
);

const PhonicsSection _sightWords = PhonicsSection(
  id: 'p-sight-words',
  titleAr: 'الكلمات البصرية الشائعة',
  titleEn: 'Sight Words',
  items: <PhonicsItem>[
    PhonicsItem('the', 'أشهر كلمة في الإنجليزي', 'the', 'الـ (أداة تعريف)'),
    PhonicsItem('and', 'حرف عطف', 'and', 'و'),
    PhonicsItem('is', 'من فعل الكينونة', 'is', 'يكون'),
    PhonicsItem('you', 'ضمير المخاطب', 'you', 'أنتَ / أنتِ'),
    PhonicsItem('we', 'ضمير المتكلم الجمع', 'we', 'إحنا / نحن'),
    PhonicsItem('said', 'ماضي say وبيتنطق "سِد"', 'said', 'قال'),
    PhonicsItem('come', 'لاحظ نطق o زي "آ"', 'come', 'تعالى'),
    PhonicsItem('here', 'انتبه للنطق', 'here', 'هنا'),
    PhonicsItem('what', 'كلمة استفهام', 'what', 'إيه / ماذا'),
    PhonicsItem('they', 'ضمير الغائب الجمع', 'they', 'هم'),
    PhonicsItem('good', 'صفة مشهورة', 'good', 'كويس / جيد'),
    PhonicsItem('very', 'بتيجي قبل الصفات', 'very', 'جدًا / أوي'),
  ],
);
