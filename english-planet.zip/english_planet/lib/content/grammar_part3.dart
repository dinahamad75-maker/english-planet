import '../models/models.dart';

/// Grammar lessons, part 3: Past Simple, Present Perfect.
final List<Lesson> grammarLessonsPart3 = <Lesson>[_pastSimple, _presentPerfect];

const Lesson _pastSimple = Lesson(
  id: 'g-past-simple',
  titleEn: 'Past Simple',
  titleAr: 'الماضي البسيط',
  level: 'A2',
  minutes: 10,
  introAr:
      'الماضي البسيط بنستخدمه لحدث بدأ وانتهى في وقت محدد في الماضي: أمس، الأسبوع الماضي، سنة 2010.',
  explanationAr: <String>[
    'الأفعال المنتظمة بنضيف لها ed: play→played, work→worked, visit→visited.',
    'في أفعال شاذة لازم نحفظها: go→went, eat→ate, see→saw, buy→bought, have→had.',
    'للنفي بنستخدم didn\'t + الفعل في صورته الأصلية: I didn\'t go. (مش didn\'t went).',
    'للسؤال: Did + الفاعل + الفعل الأصلي: Did you watch the match? وبنرد: Yes, I did. / No, I didn\'t.',
  ],
  examples: <LessonExample>[
    LessonExample('I visited Cairo last year.', 'زرت القاهرة السنة اللي فاتت.'),
    LessonExample('She bought a new phone yesterday.', 'هي اشترت موبايل جديد إمبارح.'),
    LessonExample('We didn\'t play tennis yesterday.', 'إحنا ملعبناش تنس إمبارح.'),
    LessonExample('Did they arrive on time? Yes, they did.', 'هل وصلوا في الميعاد؟ أيوه.'),
    LessonExample('He watched a movie last night.', 'هو اتفرج على فيلم مبارح بالليل.'),
  ],
  notesAr: <String>[
    'الكلمات الدالة عليه: yesterday, last week/month/year, ago, in 2015.',
    'بعد didn\'t وdid الفعل بيرجع لصورته الأصلية: Did you eat? مش Did you ate?',
    'نهاية ed بتتنطق بطرق مختلفة: /t/ في worked و/d/ في played و/id/ في wanted.',
  ],
  mistakes: <CommonMistake>[
    CommonMistake('I didn\'t went.', 'I didn\'t go.', 'بعد didn\'t الفعل في صورته الأصلية.'),
    CommonMistake('She buyed a dress.', 'She bought a dress.', 'buy فعل شاذ وتصريفه الماضي bought.'),
    CommonMistake('Did you saw him?', 'Did you see him?', 'بعد Did نستخدم الفعل الأصلي see.'),
  ],
  quiz: <QuizQuestion>[
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: 'We ___ a great movie last night.',
      options: <String>['watch', 'watches', 'watched', 'watching'],
      answerIndex: 2,
      explanationAr: 'last night دليل الماضي البسيط: watched.',
    ),
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: 'She ___ to Alexandria two days ago.',
      options: <String>['goes', 'went', 'go', 'going'],
      answerIndex: 1,
      explanationAr: 'الماضي من go هو went.',
    ),
    QuizQuestion(
      type: QuestionType.trueFalse,
      promptAr: 'صح ولا غلط؟',
      promptEn: 'I didn\'t ate breakfast.',
      answerIndex: 1,
      explanationAr: 'غلط. بعد didn\'t الفعل الأصلي: I didn\'t eat breakfast.',
    ),
    QuizQuestion(
      type: QuestionType.fillBlank,
      promptAr: 'أكمل الجملة:',
      promptEn: 'Did you ___ your homework? (finish)',
      options: <String>['finished', 'finishes', 'finish', 'finishing'],
      answerIndex: 2,
      explanationAr: 'بعد Did نستخدم الفعل في صورته الأصلية: finish.',
    ),
    QuizQuestion(
      type: QuestionType.arrange,
      promptAr: 'رتّب الكلمات لتكوين جملة صحيحة:',
      options: <String>['visited', 'They', 'grandma', 'their', 'yesterday'],
      arrangeAnswer: <String>['They', 'visited', 'their', 'grandma', 'yesterday'],
      explanationAr: 'فاعل + فعل ماضٍ منتظم + المفعول + الظرف الزمني.',
    ),
  ],
);

const Lesson _presentPerfect = Lesson(
  id: 'g-present-perfect',
  titleEn: 'Present Perfect',
  titleAr: 'المضارع التام',
  level: 'B1',
  minutes: 12,
  introAr:
      'المضارع التام بيربط الماضي بالحاضر: حاجة حصلت في الماضي بس أثرها لسه موجود دلوقتي، أو تجربة في حياتنا من غير وقت محدد.',
  explanationAr: <String>[
    'تكوينه: have/has + التصريف الثالث للفعل (V3). مثال: I have eaten. She has finished. مع he/she/it بنستخدم has، ومع الباقي have.',
    'استخداماته الأساسية: تجربة حياتية بوقت غير محدد (I have visited Paris)، حدث لسه حاصل قريبًا وأثره موجود (She has just left)، وشيء بدأ في الماضي ومستمر حتى الآن (We have lived here for ten years).',
    'الكلمات الدالة المشهورة: ever وnever للتجارب، just وalready وyet للأحداث القريبة، وfor وsince للمدة الزمنية.',
    'الفرق المهم عن الماضي البسيط: الماضي البسيط لحدث انتهى في وقت محدد (I saw the film yesterday)، والمضارع التام لحدث بوقت غير محدد أو أثره مستمر (I have seen the film). عشان كده ممنوع نستخدم المضارع التام مع yesterday أو last week.',
  ],
  examples: <LessonExample>[
    LessonExample('I have never eaten sushi.', 'أنا عمري ما أكلت سوشي.'),
    LessonExample('She has just finished her homework.', 'هي لسه خلاصة واجبها حالًا.'),
    LessonExample('Have you ever visited Luxor? Yes, I have.', 'هل زرت الأقصر من قبل؟ أيوه.'),
    LessonExample('We have lived here since 2015.', 'إحنا ساكنين هنا من سنة 2015.'),
    LessonExample('He has already sent the email.', 'هو بعت الإيميل بالفعل.'),
  ],
  notesAr: <String>[
    'yet بتيجي في آخر الجملة المنفية والاستفهامية: I haven\'t finished yet.',
    'since مع نقطة زمنية محددة (since Monday)، وfor مع مدة (for three days).',
    'التصريف الثالث للأفعال الشاذة محتاج حفظ: go→gone, see→seen, eat→eaten, write→written.',
  ],
  mistakes: <CommonMistake>[
    CommonMistake('I have seen him yesterday.', 'I saw him yesterday.', 'مع وقت ماضٍ محدد نستخدم الماضي البسيط مش المضارع التام.'),
    CommonMistake('She has ate lunch.', 'She has eaten lunch.', 'بعد has لازم التصريف الثالث: eaten.'),
    CommonMistake('I have living here since 2020.', 'I have lived here since 2020.', 'التكوين have + V3 مش have + الفعل مع ing.'),
  ],
  quiz: <QuizQuestion>[
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: 'She ___ already ___ her room.',
      options: <String>['has / cleaned', 'have / cleaned', 'has / clean', 'is / cleaning'],
      answerIndex: 0,
      explanationAr: 'she بتاخد has + التصريف الثالث cleaned.',
    ),
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الإجابة الصحيحة:',
      promptEn: 'I have lived here ___ 2018.',
      options: <String>['for', 'since', 'ago', 'yet'],
      answerIndex: 1,
      explanationAr: '2018 نقطة زمنية محددة، فنستخدم since.',
    ),
    QuizQuestion(
      type: QuestionType.trueFalse,
      promptAr: 'صح ولا غلط؟',
      promptEn: 'I have met him last Friday.',
      answerIndex: 1,
      explanationAr: 'غلط. last Friday وقت محدد، فالصح: I met him last Friday.',
    ),
    QuizQuestion(
      type: QuestionType.fillBlank,
      promptAr: 'أكمل الجملة:',
      promptEn: 'Have you ___ ridden a horse? (ever / already)',
      options: <String>['ever', 'already', 'since', 'for'],
      answerIndex: 0,
      explanationAr: 'في السؤال عن تجربة حياتية بنستخدم ever.',
    ),
    QuizQuestion(
      type: QuestionType.arrange,
      promptAr: 'رتّب الكلمات لتكوين جملة صحيحة:',
      options: <String>['has', 'just', 'She', 'arrived'],
      arrangeAnswer: <String>['She', 'has', 'just', 'arrived'],
      explanationAr: 'just بتيجي بين has والتصريف الثالث.',
    ),
  ],
);
