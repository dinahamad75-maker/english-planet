import '../models/models.dart';
import 'grammar_part1.dart';
import 'grammar_part2.dart';
import 'grammar_part3.dart';

/// Grammar Academy content: a small, carefully reviewed set of complete
/// lessons. Each lesson carries its own quiz. New lessons are added in the
/// grammar_partN.dart files, without touching application logic.
final List<Lesson> grammarLessons = <Lesson>[
  ...grammarLessonsPart1,
  ...grammarLessonsPart2,
  ...grammarLessonsPart3,
];

Lesson? grammarById(String id) {
  for (final Lesson l in grammarLessons) {
    if (l.id == id) return l;
  }
  return null;
}
