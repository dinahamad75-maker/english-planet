import 'package:flutter/material.dart';

import '../models/models.dart';
import '../theme/app_theme.dart';

/// Vocabulary topics, part 1: Daily Life, Family.
final List<VocabTopic> vocabTopicsPart1 = <VocabTopic>[_dailyLife, _family];

const VocabTopic _dailyLife = VocabTopic(
  id: 'v-daily-life',
  titleAr: 'الحياة اليومية',
  titleEn: 'Daily Life',
  icon: Icons.wb_sunny_rounded,
  color: AppColors.sky,
  words: <VocabWord>[
    VocabWord(
      en: 'morning',
      ar: 'صباح',
      phonetic: '/ˈmɔːrnɪŋ/',
      exampleEn: 'I wake up early in the morning.',
      exampleAr: 'بصحى بدري في الصباح.'),
    VocabWord(
      en: 'breakfast',
      ar: 'فطار',
      phonetic: '/ˈbrekfəst/',
      exampleEn: 'We eat breakfast at eight o\'clock.',
      exampleAr: 'بنفطر الساعة تمانية.'),
    VocabWord(
      en: 'work',
      ar: 'شغل / عمل',
      phonetic: '/wɜːrk/',
      exampleEn: 'My father goes to work by car.',
      exampleAr: 'أبويا بيروح الشغل بالعربية.'),
    VocabWord(
      en: 'house',
      ar: 'بيت / منزل',
      phonetic: '/haʊs/',
      exampleEn: 'Their house is near the school.',
      exampleAr: 'بيتهم قريب من المدرسة.'),
    VocabWord(
      en: 'money',
      ar: 'فلوس / نقود',
      phonetic: '/ˈmʌni/',
      exampleEn: 'She saves money every month.',
      exampleAr: 'هي بتوفر فلوس كل شهر.'),
    VocabWord(
      en: 'friend',
      ar: 'صديق / صديقة',
      phonetic: '/frend/',
      exampleEn: 'He is my best friend.',
      exampleAr: 'هو أعز صديق ليا.'),
    VocabWord(
      en: 'street',
      ar: 'شارع',
      phonetic: '/striːt/',
      exampleEn: 'Our street is very quiet.',
      exampleAr: 'الشارع بتاعنا هادي جدًا.'),
    VocabWord(
      en: 'time',
      ar: 'وقت',
      phonetic: '/taɪm/',
      exampleEn: 'What time is it now?',
      exampleAr: 'الساعة كام دلوقتي؟'),
    VocabWord(
      en: 'day',
      ar: 'يوم',
      phonetic: '/deɪ/',
      exampleEn: 'Have a nice day!',
      exampleAr: 'يومك سعيد!'),
    VocabWord(
      en: 'night',
      ar: 'ليل',
      phonetic: '/naɪt/',
      exampleEn: 'I read a book at night.',
      exampleAr: 'بقرا كتاب بالليل.'),
  ],
);

const VocabTopic _family = VocabTopic(
  id: 'v-family',
  titleAr: 'العائلة',
  titleEn: 'Family',
  icon: Icons.family_restroom_rounded,
  color: AppColors.coral,
  words: <VocabWord>[
    VocabWord(
      en: 'mother',
      ar: 'أم',
      phonetic: '/ˈmʌðər/',
      exampleEn: 'My mother cooks delicious food.',
      exampleAr: 'ماما بتطبخ أكل جميل.'),
    VocabWord(
      en: 'father',
      ar: 'أب',
      phonetic: '/ˈfɑːðər/',
      exampleEn: 'Her father is a teacher.',
      exampleAr: 'أبوها مدرس.'),
    VocabWord(
      en: 'brother',
      ar: 'أخ',
      phonetic: '/ˈbrʌðər/',
      exampleEn: 'My brother is older than me.',
      exampleAr: 'أخويا أكبر مني.'),
    VocabWord(
      en: 'sister',
      ar: 'أخت',
      phonetic: '/ˈsɪstər/',
      exampleEn: 'I play with my little sister.',
      exampleAr: 'بلعب مع أختي الصغيرة.'),
    VocabWord(
      en: 'grandfather',
      ar: 'جد',
      phonetic: '/ˈɡrænfɑːðər/',
      exampleEn: 'My grandfather tells wonderful stories.',
      exampleAr: 'جدي بيحكي حكايات جميلة.'),
    VocabWord(
      en: 'grandmother',
      ar: 'جدة',
      phonetic: '/ˈɡrænmʌðər/',
      exampleEn: 'We visit our grandmother on Fridays.',
      exampleAr: 'بنزور تيتة يوم الجمعة.'),
    VocabWord(
      en: 'uncle',
      ar: 'عم / خال',
      phonetic: '/ˈʌŋkl/',
      exampleEn: 'My uncle lives in Alexandria.',
      exampleAr: 'عمي ساكن في إسكندرية.'),
    VocabWord(
      en: 'aunt',
      ar: 'عمة / خالة',
      phonetic: '/ænt/',
      exampleEn: 'My aunt makes the best cakes.',
      exampleAr: 'خالتي بتعمل أحلى كيك.'),
    VocabWord(
      en: 'baby',
      ar: 'طفل رضيع',
      phonetic: '/ˈbeɪbi/',
      exampleEn: 'The baby is sleeping now.',
      exampleAr: 'البيبي نايم دلوقتي.'),
    VocabWord(
      en: 'parents',
      ar: 'الوالدان',
      phonetic: '/ˈperənts/',
      exampleEn: 'Her parents are very kind.',
      exampleAr: 'والديها طيبين جدًا.'),
  ],
);
