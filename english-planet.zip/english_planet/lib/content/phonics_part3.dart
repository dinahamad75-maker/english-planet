import '../models/models.dart';

/// Phonics and reading content, part 3: vowel focus. How to tell short
/// vowels from long vowels, many examples per vowel, and minimal-pair
/// practice. Requested expansion: short vs long vowels with lots of
/// examples and practice words for each.
final List<PhonicsSection> phonicsSectionsPart3 = <PhonicsSection>[
  _vowelRules,
  _vowelA,
  _vowelE,
  _vowelI,
  _vowelO,
  _vowelU,
  _vowelPractice,
];

const PhonicsSection _vowelRules = PhonicsSection(
  id: 'p-vowel-rules',
  titleAr: 'قصير ولا طويل؟ إزاي تعرف',
  titleEn: 'Short or Long? How to Tell',
  items: <PhonicsItem>[
    PhonicsItem('قاعدة CVC', 'متحرك محصور بين ساكنين بيتنطق قصير',
        'cat', 'قطة'),
    PhonicsItem('الـ e السحرية', 'e ساكنة في الآخر بتخلي المتحرك اللي قبلها طويل',
        'cake', 'كيكة'),
    PhonicsItem('متحركان مع بعض', 'أول متحرك يتنطق طويل والتاني ساكت',
        'boat', 'قارب'),
    PhonicsItem('مقطع مفتوح', 'متحرك في آخر المقطع بيتنطق طويل',
        'go', 'يروح'),
    PhonicsItem('الحرف بينطق اسمه', 'المتحرك الطويل صوته زي اسم الحرف نفسه',
        'name', 'اسم'),
    PhonicsItem('اسمع الفرق', 'قارن بين القصير والطويل في نفس الكلمة تقريبًا',
        'ship - sheep', 'مركب - خروف'),
  ],
);

const PhonicsSection _vowelA = PhonicsSection(
  id: 'p-vowel-a',
  titleAr: 'حرف A: القصير والطويل',
  titleEn: 'Letter A: Short and Long',
  items: <PhonicsItem>[
    PhonicsItem('a قصير', 'صوت "آ" قصير', 'cat', 'قطة'),
    PhonicsItem('a قصير', 'صوت "آ" قصير', 'bag', 'شنطة'),
    PhonicsItem('a قصير', 'صوت "آ" قصير', 'hat', 'قبعة'),
    PhonicsItem('a قصير', 'صوت "آ" قصير', 'man', 'راجل'),
    PhonicsItem('a قصير', 'صوت "آ" قصير', 'apple', 'تفاحة'),
    PhonicsItem('a طويل', 'بيتنطق "إي" زي اسم الحرف', 'cake', 'كيكة'),
    PhonicsItem('a طويل', 'بيتنطق "إي" زي اسم الحرف', 'name', 'اسم'),
    PhonicsItem('a طويل', 'بيتنطق "إي" (متحركان ai)', 'rain', 'مطر'),
    PhonicsItem('a طويل', 'بيتنطق "إي" (ay في الآخر)', 'day', 'يوم'),
    PhonicsItem('قارن بنفسك', 'نفس الحرف: قصير من غير e وطويل معاها',
        'hat - hate', 'قبعة - يكره'),
  ],
);

const PhonicsSection _vowelE = PhonicsSection(
  id: 'p-vowel-e',
  titleAr: 'حرف E: القصير والطويل',
  titleEn: 'Letter E: Short and Long',
  items: <PhonicsItem>[
    PhonicsItem('e قصير', 'صوت "إيه" قصير', 'bed', 'سرير'),
    PhonicsItem('e قصير', 'صوت "إيه" قصير', 'pen', 'قلم'),
    PhonicsItem('e قصير', 'صوت "إيه" قصير', 'ten', 'عشرة'),
    PhonicsItem('e قصير', 'صوت "إيه" قصير', 'red', 'أحمر'),
    PhonicsItem('e قصير', 'صوت "إيه" قصير', 'egg', 'بيضة'),
    PhonicsItem('e طويل', 'بيتنطق "إيي" طويلة زي اسم الحرف', 'he', 'هو'),
    PhonicsItem('e طويل', 'بيتنطق "إيي" طويلة زي اسم الحرف', 'she', 'هي'),
    PhonicsItem('e طويل', 'بيتنطق "إيي" (متحركان ee)', 'tree', 'شجرة'),
    PhonicsItem('e طويل', 'بيتنطق "إيي" (متحركان ea)', 'eat', 'ياكل'),
    PhonicsItem('قارن بنفسك', 'قصير من غير e ساكنة وطويل معاها',
        'pet - Pete', 'حيوان أليف - اسم ولد'),
  ],
);

const PhonicsSection _vowelI = PhonicsSection(
  id: 'p-vowel-i',
  titleAr: 'حرف I: القصير والطويل',
  titleEn: 'Letter I: Short and Long',
  items: <PhonicsItem>[
    PhonicsItem('i قصير', 'صوت "إي" قصير وسريع', 'sit', 'يقعد'),
    PhonicsItem('i قصير', 'صوت "إي" قصير وسريع', 'pin', 'دبوس'),
    PhonicsItem('i قصير', 'صوت "إي" قصير وسريع', 'fish', 'سمكة'),
    PhonicsItem('i قصير', 'صوت "إي" قصير وسريع', 'milk', 'لبن'),
    PhonicsItem('i قصير', 'صوت "إي" قصير وسريع', 'big', 'كبير'),
    PhonicsItem('i طويل', 'بيتنطق "آي" زي اسم الحرف', 'kite', 'طيارة ورق'),
    PhonicsItem('i طويل', 'بيتنطق "آي" زي اسم الحرف', 'five', 'خمسة'),
    PhonicsItem('i طويل', 'بيتنطق "آي" زي اسم الحرف', 'time', 'وقت'),
    PhonicsItem('i طويل', 'بيتنطق "آي" (igh)', 'night', 'ليل'),
    PhonicsItem('قارن بنفسك', 'قصير من غير e ساكنة وطويل معاها',
        'kit - kite', 'عدة - طيارة ورق'),
  ],
);

const PhonicsSection _vowelO = PhonicsSection(
  id: 'p-vowel-o',
  titleAr: 'حرف O: القصير والطويل',
  titleEn: 'Letter O: Short and Long',
  items: <PhonicsItem>[
    PhonicsItem('o قصير', 'صوت "أو" قصير', 'dog', 'كلب'),
    PhonicsItem('o قصير', 'صوت "أو" قصير', 'hot', 'سخن'),
    PhonicsItem('o قصير', 'صوت "أو" قصير', 'box', 'علبة'),
    PhonicsItem('o قصير', 'صوت "أو" قصير', 'top', 'قمة'),
    PhonicsItem('o قصير', 'صوت "أو" قصير', 'orange', 'برتقالة'),
    PhonicsItem('o طويل', 'بيتنطق "أووو" زي اسم الحرف', 'home', 'بيت'),
    PhonicsItem('o طويل', 'بيتنطق "أووو" زي اسم الحرف', 'nose', 'أنف'),
    PhonicsItem('o طويل', 'بيتنطق "أووو" (متحركان oa)', 'boat', 'قارب'),
    PhonicsItem('o طويل', 'بيتنطق "أووو" (ow في الآخر)', 'snow', 'تلج'),
    PhonicsItem('قارن بنفسك', 'قصير من غير e ساكنة وطويل معاها',
        'hop - hope', 'ينط - يتمنى'),
  ],
);

const PhonicsSection _vowelU = PhonicsSection(
  id: 'p-vowel-u',
  titleAr: 'حرف U: القصير والطويل',
  titleEn: 'Letter U: Short and Long',
  items: <PhonicsItem>[
    PhonicsItem('u قصير', 'صوت "آ" مفتوح قصير', 'cup', 'كوباية'),
    PhonicsItem('u قصير', 'صوت "آ" مفتوح قصير', 'bus', 'أتوبيس'),
    PhonicsItem('u قصير', 'صوت "آ" مفتوح قصير', 'sun', 'شمس'),
    PhonicsItem('u قصير', 'صوت "آ" مفتوح قصير', 'duck', 'بطة'),
    PhonicsItem('u قصير', 'صوت "آ" مفتوح قصير', 'mum', 'ماما'),
    PhonicsItem('u طويل', 'بيتنطق "يو" زي اسم الحرف', 'cube', 'مكعب'),
    PhonicsItem('u طويل', 'بيتنطق "يو" زي اسم الحرف', 'music', 'مزيكا'),
    PhonicsItem('u طويل', 'بيتنطق "يو" زي اسم الحرف', 'cute', 'جميل/لطيف'),
    PhonicsItem('u طويل (تاني)', 'أحيانًا بيتنطق "ووو" طويلة', 'blue', 'أزرق'),
    PhonicsItem('قارن بنفسك', 'قصير من غير e ساكنة وطويل معاها',
        'cub - cube', 'شبل - مكعب'),
  ],
);

const PhonicsSection _vowelPractice = PhonicsSection(
  id: 'p-vowels-practice',
  titleAr: 'تدريب: اسمع الفرق',
  titleEn: 'Practice: Hear the Difference',
  items: <PhonicsItem>[
    PhonicsItem('hat / hate', 'a قصير وبعدين a طويل', 'hat - hate', 'قبعة - يكره'),
    PhonicsItem('cap / cape', 'a قصير وبعدين a طويل', 'cap - cape', 'طاقية - عباءة'),
    PhonicsItem('mad / made', 'a قصير وبعدين a طويل', 'mad - made', 'مجنون - صنع'),
    PhonicsItem('pet / Pete', 'e قصير وبعدين e طويل', 'pet - Pete', 'حيوان أليف - اسم ولد'),
    PhonicsItem('kit / kite', 'i قصير وبعدين i طويل', 'kit - kite', 'عدة - طيارة ورق'),
    PhonicsItem('pin / pine', 'i قصير وبعدين i طويل', 'pin - pine', 'دبوس - صنوبر'),
    PhonicsItem('hop / hope', 'o قصير وبعدين o طويل', 'hop - hope', 'ينط - يتمنى'),
    PhonicsItem('not / note', 'o قصير وبعدين o طويل', 'not - note', 'ليس - ملاحظة'),
    PhonicsItem('cub / cube', 'u قصير وبعدين u طويل', 'cub - cube', 'شبل - مكعب'),
    PhonicsItem('tub / tube', 'u قصير وبعدين u طويل', 'tub - tube', 'حوض - أنبوبة'),
  ],
);
