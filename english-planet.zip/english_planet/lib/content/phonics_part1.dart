import '../models/models.dart';

/// Phonics and reading content, part 1: alphabet, short vowels, long
/// vowels, CVC words. Designed for tap-to-hear practice.
final List<PhonicsSection> phonicsSectionsPart1 = <PhonicsSection>[
  _alphabet,
  _shortVowels,
  _longVowels,
  _cvc,
];

const PhonicsSection _alphabet = PhonicsSection(
  id: 'p-alphabet',
  titleAr: 'الحروف الأبجدية',
  titleEn: 'The Alphabet',
  items: <PhonicsItem>[
    PhonicsItem('Aa', 'صوت قصير "آ" زي في كلمة', 'apple', 'تفاحة'),
    PhonicsItem('Bb', 'صوت "ب"', 'ball', 'كورة'),
    PhonicsItem('Cc', 'صوت "ك"', 'cat', 'قطة'),
    PhonicsItem('Dd', 'صوت "د"', 'dog', 'كلب'),
    PhonicsItem('Ee', 'صوت قصير "إيه"', 'egg', 'بيضة'),
    PhonicsItem('Ff', 'صوت "ف"', 'fish', 'سمكة'),
    PhonicsItem('Gg', 'صوت "ج" (زي "ج" في جمل)', 'goat', 'ماعز'),
    PhonicsItem('Hh', 'صوت "هـ"', 'hat', 'قبعة'),
    PhonicsItem('Ii', 'صوت قصير "إي"', 'ink', 'حبر'),
    PhonicsItem('Jj', 'صوت "جي"', 'juice', 'عصير'),
    PhonicsItem('Kk', 'صوت "ك"', 'kite', 'طيارة ورق'),
    PhonicsItem('Ll', 'صوت "ل"', 'lion', 'أسد'),
    PhonicsItem('Mm', 'صوت "م"', 'moon', 'قمر'),
    PhonicsItem('Nn', 'صوت "ن"', 'nose', 'أنف'),
    PhonicsItem('Oo', 'صوت قصير "أو"', 'orange', 'برتقالة'),
    PhonicsItem('Pp', 'صوت "ب" قوي', 'pen', 'قلم'),
    PhonicsItem('Qq', 'صوت "كو"', 'queen', 'ملكة'),
    PhonicsItem('Rr', 'صوت "ر" ناعمة', 'rabbit', 'أرنب'),
    PhonicsItem('Ss', 'صوت "س"', 'sun', 'شمس'),
    PhonicsItem('Tt', 'صوت "ت"', 'tiger', 'نمر'),
    PhonicsItem('Uu', 'صوت قصير "آ"', 'umbrella', 'شمسية'),
    PhonicsItem('Vv', 'صوت "ڤ"', 'van', 'عربية نقل'),
    PhonicsItem('Ww', 'صوت "و"', 'water', 'مية'),
    PhonicsItem('Xx', 'صوت "كس"', 'box', 'علبة (بتيجي في الآخر غالبًا)'),
    PhonicsItem('Yy', 'صوت "ي"', 'yellow', 'أصفر'),
    PhonicsItem('Zz', 'صوت "ز"', 'zebra', 'حمار وحشي'),
  ],
);

const PhonicsSection _shortVowels = PhonicsSection(
  id: 'p-short-vowels',
  titleAr: 'الحروف المتحركة القصيرة',
  titleEn: 'Short Vowels',
  items: <PhonicsItem>[
    PhonicsItem('a', 'صوت "آ" قصير', 'cat', 'قطة'),
    PhonicsItem('e', 'صوت "إيه" قصير', 'bed', 'سرير'),
    PhonicsItem('i', 'صوت "إي" قصير', 'sit', 'يقعد'),
    PhonicsItem('o', 'صوت "أو" قصير', 'dog', 'كلب'),
    PhonicsItem('u', 'صوت "آ" قصير مفتوح', 'cup', 'كوباية'),
  ],
);

const PhonicsSection _longVowels = PhonicsSection(
  id: 'p-long-vowels',
  titleAr: 'الحروف المتحركة الطويلة',
  titleEn: 'Long Vowels',
  items: <PhonicsItem>[
    PhonicsItem('a_e', 'الحرف بيقول اسمه "إي" مع e ساكنة', 'cake', 'كيكة'),
    PhonicsItem('ee', 'صوت "إيي" طويل', 'tree', 'شجرة'),
    PhonicsItem('i_e', 'الحرف بيقول اسمه "آي"', 'bike', 'عجلة'),
    PhonicsItem('oa', 'صوت "أوو" طويل', 'boat', 'مركب'),
    PhonicsItem('u_e', 'الحرف بيقول اسمه "يو"', 'cube', 'مكعب'),
  ],
);

const PhonicsSection _cvc = PhonicsSection(
  id: 'p-cvc',
  titleAr: 'كلمات CVC (ساكن-متحرك-ساكن)',
  titleEn: 'CVC Words',
  items: <PhonicsItem>[
    PhonicsItem('c-a-t', 'انطق كل صوت لوحده وبعدين ادمجهم', 'cat', 'قطة'),
    PhonicsItem('d-o-g', 'ادمج الأصوات الثلاثة بسرعة', 'dog', 'كلب'),
    PhonicsItem('s-u-n', 'صوت s واضح في الأول', 'sun', 'شمس'),
    PhonicsItem('b-e-d', 'الصوت الوسطاني قصير', 'bed', 'سرير'),
    PhonicsItem('p-i-g', 'انتبه للـ i القصيرة', 'pig', 'خنزير'),
    PhonicsItem('h-a-t', 'ابدأ بالـ h بخفة', 'hat', 'قبعة'),
  ],
);
