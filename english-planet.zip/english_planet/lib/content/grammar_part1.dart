import '../models/models.dart';

/// Grammar lessons, part 1: Verb To Be, Articles.
final List<Lesson> grammarLessonsPart1 = <Lesson>[_verbToBe, _articles];

const Lesson _verbToBe = Lesson(
  id: 'g-verb-to-be',
  titleEn: 'Verb To Be',
  titleAr: 'فعل الكينونة (am / is / are)',
  level: 'Pre-A1',
  minutes: 8,
  introAr:
      'فعل "to be" هو أهم فعل في اللغة الإنجليزية. بنستخدمه عشان نقول مين إحنا، أو إيه حاجة، أو إزاي حالنا: أنا طالبة، هو سعيد، هما في البيت.',
  explanationAr: <String>[
    'في المضارع البسيط، فعل "to be" له ثلاث صور: am مع "I"، وis مع المفرد الغائب (he / she / it)، وare مع الجمع و"you".',
    'ترتيب الجملة بسيط: الفاعل + am/is/are + باقي الجملة. مثال: She is a teacher. (هي معلمة).',
    'للنفي بنضيف not بعد الفعل مباشرة: I am not tired. وفي الكلام اليومي بتختصر: isn\'t وaren\'t.',
    'للسؤال بنقدّم الفعل قبل الفاعل: Are you ready? / Is she at home? وبنرد بإجابة قصيرة: Yes, I am. / No, she isn\'t.',
  ],
  examples: <LessonExample>[
    LessonExample('I am a student.', 'أنا طالب / طالبة.'),
    LessonExample('She is a doctor.', 'هي دكتورة.'),
    LessonExample('They are at school.', 'هم في المدرسة.'),
    LessonExample('We are not late.', 'إحنا مش متأخرين.'),
    LessonExample('Is it hot today? Yes, it is.', 'هل الجو حار النهارده؟ أيوه.'),
  ],
  notesAr: <String>[
    'الضمير "it" بنستخدمه للأشياء والحيوانات والطقس، ومبياخدش غير is.',
    'الاختصارات شائعة جدًا في الكلام: I\'m, you\'re, he\'s, she\'s, it\'s, we\'re, they\'re.',
    'ممنوع نستخدم am مع غير I: مفيش "he am" أبدًا.',
  ],
  mistakes: <CommonMistake>[
    CommonMistake('He am happy.', 'He is happy.', 'he مفرد غائب، فبنستخدم is مش am.'),
    CommonMistake('They is my friends.', 'They are my friends.', 'they جمع، فالفعل الصحيح هي are.'),
    CommonMistake('I not tired.', 'I am not tired.', 'النفي لازم يبقى بإضافة not بعد am/is/are، مش حذف الفعل.'),
  ],
  quiz: <QuizQuestion>[
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الصورة الصحيحة من الفعل:',
      promptEn: 'She ___ a nurse.',
      options: <String>['am', 'is', 'are', 'be'],
      answerIndex: 1,
      explanationAr: 'she مفرد غائب، فبنستخدم is.',
    ),
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الصورة الصحيحة من الفعل:',
      promptEn: 'We ___ happy today.',
      options: <String>['is', 'am', 'are', 'be'],
      answerIndex: 2,
      explanationAr: 'we جمع، فبنستخدم are.',
    ),
    QuizQuestion(
      type: QuestionType.trueFalse,
      promptAr: 'صح ولا غلط؟',
      promptEn: 'They is at home.',
      answerIndex: 1,
      explanationAr: 'غلط. they جمع فلازم نقول They are at home.',
    ),
    QuizQuestion(
      type: QuestionType.fillBlank,
      promptAr: 'أكمل الجملة بالكلمة المناسبة:',
      promptEn: '___ you ready? Yes, I am.',
      options: <String>['Is', 'Am', 'Are', 'Be'],
      answerIndex: 2,
      explanationAr: 'في السؤال مع you بنستخدم Are في أول الجملة.',
    ),
    QuizQuestion(
      type: QuestionType.arrange,
      promptAr: 'رتّب الكلمات لتكوين جملة صحيحة:',
      options: <String>['is', 'My', 'a', 'teacher', 'mother'],
      arrangeAnswer: <String>['My', 'mother', 'is', 'a', 'teacher'],
      explanationAr: 'الترتيب الصحيح: الفاعل (My mother) ثم is ثم باقي الجملة.',
    ),
  ],
);

const Lesson _articles = Lesson(
  id: 'g-articles',
  titleEn: 'Articles: a / an / the',
  titleAr: 'أدوات التعريف والتنكير (a / an / the)',
  level: 'A1',
  minutes: 8,
  introAr:
      'الأدوات a وan وthe كلمات صغيرة لكنها مهمة جدًا. a وan للتنكير (أي حاجة غير محددة)، وthe للتعريف (حاجة محددة إحنا وسامعنا عارفينها).',
  explanationAr: <String>[
    'بنستخدم a قبل الكلمات اللي بتبدأ بصوت ساكن (consonant sound): a book, a car, a university (لأنها بتتنطق "يونيفرسيتي" يعني بصوت y الساكن).',
    'بنستخدم an قبل الكلمات اللي بتبدأ بصوت متحرك حقيقي (a, e, i, o, u): an apple, an egg, an hour (لأن h في hour ساكنة مش بتتنطق).',
    'بنستخدم the لما الشيء يكون محدد أو معروف للطرفين: The sun is bright. / I opened the door. (الباب اللي قصدناه).',
    'ملحوظة: أسماء البلاد والمدن والأشخاص في الغالب مبنستخدمش معاها the، باستثناءات مثل: the United States, the Nile.',
  ],
  examples: <LessonExample>[
    LessonExample('I have a cat.', 'عندي قطة (أي قطة).'),
    LessonExample('She ate an orange.', 'هي أكلت برتقالة.'),
    LessonExample('The moon is beautiful tonight.', 'القمر جميل الليلة.'),
    LessonExample('He is an honest man.', 'هو رجل أمين (h في honest ساكنة).'),
    LessonExample('Close the window, please.', 'اقفل الشباك من فضلك (الشباك المعروف).'),
  ],
  notesAr: <String>[
    'الاختيار بين a وan بيعتمد على النطق مش الحرف المكتوب: an hour لكن a university.',
    'الأسماء الجمع والأسماء غير المعدودة مبتاخدش a/an: نقول water مش a water.',
    'أول مرة نذكر حاجة بنستخدم a/an، وبعدها لما نعيد ذكرها نستخدم the.',
  ],
  mistakes: <CommonMistake>[
    CommonMistake('I saw elephant.', 'I saw an elephant.', 'الاسم المفرد المعدود محتاج أداة تنكير قبله.'),
    CommonMistake('She is a honest girl.', 'She is an honest girl.', 'كلمة honest بتبدأ بصوت متحرك، فنستخدم an.'),
    CommonMistake('I drink a water.', 'I drink water.', 'الماء اسم غير معدود، مبنستخدمش معاه a.'),
  ],
  quiz: <QuizQuestion>[
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الأداة الصحيحة:',
      promptEn: 'I ate ___ apple.',
      options: <String>['a', 'an', 'the', '-'],
      answerIndex: 1,
      explanationAr: 'apple بتبدأ بصوت متحرك، فنستخدم an.',
    ),
    QuizQuestion(
      type: QuestionType.mcq,
      promptAr: 'اختر الأداة الصحيحة:',
      promptEn: '___ sun rises in the east.',
      options: <String>['A', 'An', 'The', '-'],
      answerIndex: 2,
      explanationAr: 'الشمس شيء واحد معروف في العالم، فنستخدم The.',
    ),
    QuizQuestion(
      type: QuestionType.trueFalse,
      promptAr: 'صح ولا غلط؟',
      promptEn: 'He is an university student.',
      answerIndex: 1,
      explanationAr: 'غلط. university بتتنطق بصوت y الساكن، فالصح: a university student.',
    ),
    QuizQuestion(
      type: QuestionType.fillBlank,
      promptAr: 'أكمل الجملة:',
      promptEn: 'It takes ___ hour to get there.',
      options: <String>['a', 'an', 'the', '-'],
      answerIndex: 1,
      explanationAr: 'hour بتتنطق "آور" والـ h ساكنة، فنستخدم an.',
    ),
    QuizQuestion(
      type: QuestionType.arrange,
      promptAr: 'رتّب الكلمات لتكوين جملة صحيحة:',
      options: <String>['a', 'has', 'new', 'Sara', 'bag'],
      arrangeAnswer: <String>['Sara', 'has', 'a', 'new', 'bag'],
      explanationAr: 'a new bag: أداة التنكير a قبل الصفة اللي بتبدأ بصوت ساكن.',
    ),
  ],
);
