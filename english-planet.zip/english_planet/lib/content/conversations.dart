import '../models/models.dart';

/// Everyday English conversations: practical dialogues with Arabic support.
final List<Conversation> conversations = <Conversation>[
  _introductions,
  _restaurant,
  _airport,
  _shopping,
];

Conversation? conversationById(String id) {
  for (final Conversation c in conversations) {
    if (c.id == id) return c;
  }
  return null;
}

const Conversation _introductions = Conversation(
  id: 'c-introductions',
  titleAr: 'التعريف بالنفس',
  titleEn: 'Introducing Yourself',
  sceneAr: 'شخصان بيتقابلوا لأول مرة في دورة تدريبية.',
  lines: <ConversationLine>[
    ConversationLine('A', 'Hi! My name is Sara. What\'s your name?', 'أهلًا! اسمي سارة. ما اسمك؟'),
    ConversationLine('B', 'Hello Sara, I\'m Omar. Nice to meet you.', 'أهلًا يا سارة، أنا عمر. سعيد بلقائك.'),
    ConversationLine('A', 'Nice to meet you too, Omar. Where are you from?', 'وأنا سعيدة بلقائك يا عمر. من أين أنت؟'),
    ConversationLine('B', 'I\'m from Cairo. And you?', 'أنا من القاهرة. وأنتِ؟'),
    ConversationLine('A', 'I\'m from Mansoura. What do you do?', 'أنا من المنصورة. ماذا تعمل؟'),
    ConversationLine('B', 'I\'m an engineer. I work at a software company.', 'أنا مهندس. بشتغل في شركة برمجيات.'),
    ConversationLine('A', 'That\'s interesting! I\'m a teacher.', 'ده ممتع! أنا مدرّسة.'),
  ],
);

const Conversation _restaurant = Conversation(
  id: 'c-restaurant',
  titleAr: 'في المطعم',
  titleEn: 'At the Restaurant',
  sceneAr: 'زبونة بتطلب الأكل في مطعم.',
  lines: <ConversationLine>[
    ConversationLine('Waiter', 'Good evening! A table for two?', 'مساء الخير! طاولة لشخصين؟'),
    ConversationLine('Customer', 'Yes, please. Can I see the menu?', 'أيوه من فضلك. ممكن أشوف قائمة الأكل؟'),
    ConversationLine('Waiter', 'Of course. Here you are. Are you ready to order?', 'اتفضلي. هل أنتِ جاهزة للطلب؟'),
    ConversationLine('Customer', 'Yes. I\'d like the grilled chicken, please.', 'أيوه. عايزة الفراخ المشوية من فضلك.'),
    ConversationLine('Waiter', 'Anything to drink?', 'تحبي تشربي إيه؟'),
    ConversationLine('Customer', 'Just water, please. And could we have some bread?', 'مية بس من فضلك. وممكن شوية عيش كمان؟'),
    ConversationLine('Waiter', 'Sure. It will be ready in fifteen minutes.', 'حاضر. الطلب هيبقى جاهز في ربع ساعة.'),
    ConversationLine('Customer', 'Thank you so much!', 'شكرًا جدًا!'),
  ],
);

const Conversation _airport = Conversation(
  id: 'c-airport',
  titleAr: 'في المطار',
  titleEn: 'At the Airport',
  sceneAr: 'مسافر عند شباك التفتيش في المطار.',
  lines: <ConversationLine>[
    ConversationLine('Officer', 'May I see your passport, please?', 'ممكن أشوف جواز السفر من فضلك؟'),
    ConversationLine('Traveler', 'Of course. Here you go.', 'طبعًا. اتفضل.'),
    ConversationLine('Officer', 'What is the purpose of your visit?', 'ما هو غرض الزيارة؟'),
    ConversationLine('Traveler', 'I\'m here on holiday for one week.', 'أنا هنا في أجازة لمدة أسبوع.'),
    ConversationLine('Officer', 'Where will you be staying?', 'أين ستقيم؟'),
    ConversationLine('Traveler', 'At the Sunrise Hotel, near the city center.', 'في فندق صن رايز، جنب وسط المدينة.'),
    ConversationLine('Officer', 'Great. Enjoy your stay!', 'جميل. أتمنى لك إقامة سعيدة!'),
    ConversationLine('Traveler', 'Thank you very much.', 'شكرًا جزيلًا.'),
  ],
);

const Conversation _shopping = Conversation(
  id: 'c-shopping',
  titleAr: 'التسوق',
  titleEn: 'Shopping',
  sceneAr: 'زبونة بتشتري هدوم في محل.',
  lines: <ConversationLine>[
    ConversationLine('Assistant', 'Hello! Can I help you?', 'أهلًا! أقدر أساعدك؟'),
    ConversationLine('Customer', 'Yes, please. I\'m looking for a dress.', 'أيوه من فضلك. بدور على فستان.'),
    ConversationLine('Assistant', 'What size are you?', 'ما مقاسك؟'),
    ConversationLine('Customer', 'I\'m a medium. Do you have this one in blue?', 'مقاسي وسط. عندكم ده باللون الأزرق؟'),
    ConversationLine('Assistant', 'Let me check... Yes, we do. Would you like to try it on?', 'لحظة أشوف... أيوه موجود. تحبي تيجريه؟'),
    ConversationLine('Customer', 'Yes, please. Where is the fitting room?', 'أيوه من فضلك. فين غرفة القياس؟'),
    ConversationLine('Assistant', 'It\'s over there, on your right.', 'هناك، على يمينك.'),
    ConversationLine('Customer', 'It fits perfectly! How much is it?', 'مظبوط تمامًا! بكام؟'),
    ConversationLine('Assistant', 'It\'s on sale today: two hundred pounds instead of three hundred.', 'عليه خصم النهارده: ميتين جنيه بدل تلتمية.'),
    ConversationLine('Customer', 'Perfect. I\'ll take it.', 'تمام. هاخده.'),
  ],
);
