/// Rotating daily content: a word, a phrase and a challenge, picked by the
/// day of the year so every learner sees the same "daily" item.
class DailyItem {
  const DailyItem(this.en, this.ar, this.noteAr);
  final String en;
  final String ar;
  final String noteAr;
}

const List<DailyItem> dailyWords = <DailyItem>[
  DailyItem('brave', 'شجاع', 'صفة: She is a brave girl. (هي بنت شجاعة).'),
  DailyItem('journey', 'رحلة', 'اسم: Life is a journey. (الحياة رحلة).'),
  DailyItem('improve', 'يتحسّن / يطوّر', 'فعل: Practice every day to improve. (تدرّب كل يوم عشان تتحسن).'),
  DailyItem('habit', 'عادة', 'اسم: Reading is a good habit. (القراية عادة كويسة).'),
  DailyItem('achieve', 'يحقق', 'فعل: You can achieve your goals. (تقدر تحقق أهدافك).'),
  DailyItem('confident', 'واثق من نفسه', 'صفة: Speak English and be confident. (اتكلم إنجليزي وكن واثق).'),
  DailyItem('discover', 'يكتشف', 'فعل: Discover a new word today. (اكتشف كلمة جديدة النهارده).'),
  DailyItem('patience', 'صبر', 'اسم: Learning needs patience. (التعلم محتاج صبر).'),
  DailyItem('grateful', 'ممتن', 'صفة: I am grateful for my family. (أنا ممتن لعيلتي).'),
  DailyItem('challenge', 'تحدي', 'اسم: Every challenge makes you stronger. (كل تحدي بيخليك أقوى).'),
  DailyItem('kind', 'طيب / لطيف', 'صفة: Be kind to everyone. (كن طيب مع الكل).'),
  DailyItem('focus', 'تركيز', 'اسم/فعل: Focus on one thing at a time. (ركز في حاجة واحدة كل مرة).'),
  DailyItem('smile', 'ابتسامة', 'اسم: A smile opens doors. (الابتسامة بتفتح أبواب).'),
  DailyItem('dream', 'حلم', 'اسم: Follow your dream. (امشي ورا حلمك).'),
];

const List<DailyItem> dailyPhrases = <DailyItem>[
  DailyItem('How are you doing?', 'عامل إيه؟', 'طريقة ودية للسؤال عن الحال.'),
  DailyItem('That sounds great!', 'ده يبدو جميل!', 'للتعبير عن الحماس لفكرة.'),
  DailyItem('Could you repeat that, please?', 'ممكن تعيد اللي قلته من فضلك؟', 'مهذبة جدًا لما متسمعش كويس.'),
  DailyItem('I don\'t understand yet.', 'أنا لسه مش فاهم.', 'yet بتيجي في آخر الجملة المنفية.'),
  DailyItem('What do you mean?', 'إيه قصدك؟', 'لطلب التوضيح.'),
  DailyItem('Let me think about it.', 'خليني أفكر في الموضوع.', 'مفيدة لما تحتاج وقت للرد.'),
  DailyItem('It depends.', 'على حسب الظروف.', 'رد ذكي لما الإجابة مش ثابتة.'),
  DailyItem('No worries!', 'ولا يهمك!', 'رد لطيف على الاعتذار.'),
  DailyItem('Take your time.', 'خد وقتك.', 'لما حد مستعجل.'),
  DailyItem('Long time no see!', 'وحشتني! زمان عنك!', 'تحية لصديق قديم.'),
  DailyItem('I\'m on my way.', 'أنا في السكة / جاي.', 'لما تكون قريب توصل.'),
  DailyItem('Good luck!', 'بالتوفيق!', 'قبل امتحان أو مقابلة.'),
  DailyItem('Never mind.', 'متقلقش / خلاص.', 'لما تسحب سؤال أو طلب.'),
  DailyItem('See you later!', 'أشوفك بعدين!', 'وداع يومي شائع.'),
];

const List<DailyItem> dailyChallenges = <DailyItem>[
  DailyItem('Say three sentences about your day in English.', 'قول 3 جمل عن يومك بالإنجليزي.', 'ابدأ بـ I woke up... I ate... I studied...'),
  DailyItem('Name five things in your room in English.', 'سمّي 5 حاجات في أوضتك بالإنجليزي.', 'bed, door, window, desk, chair...'),
  DailyItem('Introduce yourself in English in 20 seconds.', 'عرّف نفسك بالإنجليزي في 20 ثانية.', 'اسمك، سنك، ساكن فين، بتحب إيه.'),
  DailyItem('Ask a friend one question in English.', 'اسأل صاحبك سؤال واحد بالإنجليزي.', 'مثال: What is your favorite food?'),
  DailyItem('Describe your favorite food in three sentences.', 'اوصف أكلك المفضل في 3 جمل.', 'My favorite food is... It tastes... I eat it...'),
  DailyItem('Count from 1 to 20 out loud.', 'عد من 1 لـ 20 بصوت عالي.', 'انتبه لنطق thirteen وthirty.'),
  DailyItem('Say the alphabet without stopping.', 'قول الحروف الأبجدية من غير ما توقف.', 'لو غلطت ارجع لقسم الفونكس واسمع الحروف.'),
];
