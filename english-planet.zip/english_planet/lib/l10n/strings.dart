import '../state/app_state.dart';

/// Tiny bilingual helper. UI strings are inline per screen via [tr],
/// which picks Arabic or English from the current app locale.
String tr(String ar, String en) => appState.isAr ? ar : en;
