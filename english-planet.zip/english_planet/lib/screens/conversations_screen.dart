import 'package:flutter/material.dart';

import '../content/conversations.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../services/tts.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

/// Everyday conversations list.
class ConversationsScreen extends StatelessWidget {
  const ConversationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(tr('المحادثة اليومية', 'Everyday Speaking'))),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: conversations.length,
        separatorBuilder: (_, __) => const SizedBox(height: 14),
        itemBuilder: (BuildContext context, int i) {
          final Conversation c = conversations[i];
          return Entrance(
            index: i,
            child: AppCard(
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => ConversationDetailScreen(conversation: c))),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: AppColors.coral.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.forum_rounded,
                        color: AppColors.coral),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(tr(c.titleAr, c.titleEn),
                            style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 4),
                        Text(c.sceneAr,
                            style: Theme.of(context).textTheme.bodyMedium),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      color: Theme.of(context).textTheme.bodyMedium?.color),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// One conversation rendered as a bilingual chat, line by line, with
/// tap-to-hear playback of each English line.
class ConversationDetailScreen extends StatelessWidget {
  const ConversationDetailScreen({super.key, required this.conversation});

  final Conversation conversation;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text(tr(conversation.titleAr, conversation.titleEn))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: <Widget>[
          AppCard(
            color: AppColors.yellowSoft,
            child: Row(
              children: <Widget>[
                const Icon(Icons.place_rounded, color: AppColors.navy),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    conversation.sceneAr,
                    style: const TextStyle(
                        color: AppColors.navy, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ...List<Widget>.generate(conversation.lines.length, (int i) {
            final ConversationLine line = conversation.lines[i];
            final bool left = i.isEven;
            return Entrance(
              index: i,
              child: Align(
                alignment:
                    left ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.85,
                  ),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: left ? AppColors.skySoft : AppColors.mintSoft,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(18),
                      topRight: const Radius.circular(18),
                      bottomLeft: Radius.circular(left ? 18 : 4),
                      bottomRight: Radius.circular(left ? 4 : 18),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Text(
                            line.speaker,
                            style: const TextStyle(
                              color: AppColors.navy,
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                            ),
                          ),
                          const SizedBox(width: 6),
                          GestureDetector(
                            onTap: () => TtsService.instance.speak(line.en),
                            child: const Icon(Icons.volume_up_rounded,
                                size: 18, color: AppColors.navy),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        line.en,
                        style: const TextStyle(
                          color: AppColors.navy,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        line.ar,
                        style: TextStyle(
                          color: AppColors.navy.withValues(alpha: 0.7),
                          fontSize: 13,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
