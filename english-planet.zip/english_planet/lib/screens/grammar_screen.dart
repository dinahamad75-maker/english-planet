import 'package:flutter/material.dart';

import '../content/grammar.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'lesson_screen.dart';

/// Grammar Academy: the progressive lesson list.
class GrammarScreen extends StatelessWidget {
  const GrammarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('أكاديمية القواعد', 'Grammar Academy'))),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: grammarLessons.length,
        separatorBuilder: (_, __) => const SizedBox(height: 14),
        itemBuilder: (BuildContext context, int i) {
          final Lesson lesson = grammarLessons[i];
          final bool done = appState.isLessonDone(lesson.id);
          final int? best = appState.quizScore(lesson.quizId);
          return Entrance(
            index: i,
            child: AppCard(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                    builder: (_) => LessonScreen(lesson: lesson)),
              ),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: done
                          ? AppColors.mint
                          : AppColors.sky.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      done
                          ? Icons.check_rounded
                          : Icons.menu_book_rounded,
                      color: done ? Colors.white : AppColors.sky,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(tr(lesson.titleAr, lesson.titleEn),
                            style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 4),
                        Text(
                          '${lesson.level} • ${tr('${lesson.minutes} دقائق', '${lesson.minutes} min')}'
                          '${best != null ? tr(' • أفضل نتيجة $best%', ' • best $best%') : ''}',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      color:
                          Theme.of(context).textTheme.bodyMedium?.color),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
