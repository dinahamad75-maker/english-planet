import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

/// Profile and settings: name, language, level, daily goal, dark mode,
/// and data reset. Account sign-in is intentionally left for a later phase.
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('حسابي', 'Profile'))),
      body: ListenableBuilder(
        listenable: appState,
        builder: (BuildContext context, _) {
          return ListView(
            padding: const EdgeInsets.all(20),
            children: <Widget>[
              AppCard(
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 58,
                      height: 58,
                      decoration: const BoxDecoration(
                        gradient: AppColors.skyGradient,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.person_rounded,
                          color: Colors.white, size: 30),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            appState.userName.isEmpty
                                ? tr('ضيفة كوكب التأسيس', 'English Planet guest')
                                : appState.userName,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          Text(
                            tr('وضع الضيف • تقدمك محفوظ على جهازك',
                                'Guest mode • progress saved on this device'),
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: tr('تعديل الاسم', 'Edit name'),
                      icon: const Icon(Icons.edit_rounded,
                          color: AppColors.sky),
                      onPressed: () => _editName(context),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SectionHeader(tr('الإعدادات', 'Settings')),
              const SizedBox(height: 12),
              AppCard(
                padding: EdgeInsets.zero,
                child: Column(
                  children: <Widget>[
                    _tile(
                      context,
                      icon: Icons.translate_rounded,
                      color: AppColors.sky,
                      title: tr('لغة التطبيق', 'App language'),
                      trailing: SegmentedButton<String>(
                        segments: const <ButtonSegment<String>>[
                          ButtonSegment<String>(
                              value: 'ar', label: Text('عربي')),
                          ButtonSegment<String>(
                              value: 'en', label: Text('EN')),
                        ],
                        selected: <String>{appState.locale.languageCode},
                        onSelectionChanged: (Set<String> s) =>
                            appState.setLocale(s.first),
                      ),
                    ),
                    const Divider(height: 1, indent: 16, endIndent: 16),
                    _tile(
                      context,
                      icon: Icons.dark_mode_rounded,
                      color: AppColors.navy,
                      title: tr('الوضع الليلي', 'Dark mode'),
                      trailing: Switch(
                        value: appState.darkMode,
                        onChanged: appState.setDarkMode,
                      ),
                    ),
                    const Divider(height: 1, indent: 16, endIndent: 16),
                    _tile(
                      context,
                      icon: Icons.flag_rounded,
                      color: AppColors.yellow,
                      title: tr('الهدف اليومي', 'Daily goal'),
                      trailing: DropdownButton<int>(
                        value: appState.dailyGoal,
                        underline: const SizedBox.shrink(),
                        items: const <DropdownMenuItem<int>>[
                          DropdownMenuItem<int>(value: 1, child: Text('1')),
                          DropdownMenuItem<int>(value: 2, child: Text('2')),
                          DropdownMenuItem<int>(value: 3, child: Text('3')),
                          DropdownMenuItem<int>(value: 5, child: Text('5')),
                        ],
                        onChanged: (int? v) {
                          if (v != null) appState.setDailyGoal(v);
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SectionHeader(tr('مستواي', 'My level')),
              const SizedBox(height: 12),
              AppCard(
                padding: const EdgeInsets.all(14),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: AppState.levels.map((String lv) {
                    final bool sel = appState.level == lv;
                    return ChoiceChip(
                      label: Text(lv),
                      selected: sel,
                      onSelected: (_) => appState.setLevel(lv),
                      selectedColor: AppColors.yellow,
                      labelStyle: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: sel ? AppColors.navy : null,
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 20),
              AppCard(
                color: AppColors.coralSoft,
                onTap: () => _confirmReset(context),
                child: Row(
                  children: <Widget>[
                    const Icon(Icons.restart_alt_rounded,
                        color: AppColors.coral),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        tr('مسح التقدم والبدء من جديد', 'Reset progress and start over'),
                        style: const TextStyle(
                            color: AppColors.navy,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: Text(
                  'English Planet • v0.1.0\nStart Small. Learn Big.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _tile(BuildContext context,
      {required IconData icon,
      required Color color,
      required String title,
      required Widget trailing}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: <Widget>[
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(title,
                style: Theme.of(context).textTheme.titleMedium),
          ),
          trailing,
        ],
      ),
    );
  }

  void _editName(BuildContext context) {
    final TextEditingController controller =
        TextEditingController(text: appState.userName);
    showDialog<void>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(tr('اسمك إيه؟', 'What is your name?')),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(
            hintText: tr('اكتبي اسمك', 'Type your name'),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(tr('إلغاء', 'Cancel')),
          ),
          ElevatedButton(
            onPressed: () {
              appState.setUserName(controller.text);
              Navigator.of(ctx).pop();
            },
            child: Text(tr('حفظ', 'Save')),
          ),
        ],
      ),
    );
  }

  void _confirmReset(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(tr('متأكدة؟', 'Are you sure?')),
        content: Text(tr(
          'هيمسح كل تقدمك وكلماتك المحفوظة، ومفيش رجوع.',
          'This will erase all your progress and saved words. This cannot be undone.',
        )),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(tr('إلغاء', 'Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.coral,
                foregroundColor: Colors.white),
            onPressed: () {
              appState.resetAll();
              Navigator.of(ctx).pop();
            },
            child: Text(tr('امسحي', 'Reset')),
          ),
        ],
      ),
    );
  }
}
