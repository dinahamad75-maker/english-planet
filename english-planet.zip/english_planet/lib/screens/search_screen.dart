import 'package:flutter/material.dart';

import '../content/conversations.dart';
import '../content/grammar.dart';
import '../content/vocabulary.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'conversations_screen.dart';
import 'lesson_screen.dart';
import 'vocabulary_screen.dart';

/// Global search across lessons, words and conversations.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final String q = _query.trim().toLowerCase();
    final List<Widget> results = q.isEmpty ? <Widget>[] : _search(q);

    return Scaffold(
      appBar: AppBar(title: Text(tr('بحث', 'Search'))),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
            child: TextField(
              controller: _controller,
              autofocus: true,
              onChanged: (String v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: tr('دوّري على درس أو كلمة أو محادثة...',
                    'Search a lesson, word or conversation...'),
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: Theme.of(context).cardTheme.color,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: q.isEmpty
                ? Center(
                    child: Text(
                      tr('اكتبي أي حاجة: زمن، كلمة، موقف...',
                          'Type anything: a tense, a word, a situation...'),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  )
                : results.isEmpty
                    ? Center(
                        child: Text(
                          tr('مفيش نتائج لـ "$_query"',
                              'No results for "$_query"'),
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      )
                    : ListView(
                        padding: const EdgeInsets.all(20),
                        children: results,
                      ),
          ),
        ],
      ),
    );
  }

  List<Widget> _search(String q) {
    final List<Widget> out = <Widget>[];

    bool hit(String s) => s.toLowerCase().contains(q);

    for (final Lesson l in grammarLessons) {
      if (hit(l.titleAr) || hit(l.titleEn) || hit(l.introAr)) {
        out.add(_resultTile(
          icon: Icons.menu_book_rounded,
          color: AppColors.sky,
          title: tr(l.titleAr, l.titleEn),
          subtitle: tr('درس قواعد', 'Grammar lesson'),
          onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => LessonScreen(lesson: l))),
        ));
      }
    }
    for (final VocabTopic t in vocabTopics) {
      final List<VocabWord> matches = t.words
          .where((VocabWord w) => hit(w.en) || hit(w.ar))
          .toList();
      if (matches.isNotEmpty) {
        out.add(_resultTile(
          icon: t.icon,
          color: t.color,
          title: tr(t.titleAr, t.titleEn),
          subtitle: tr('${matches.length} نتيجة في الكلمات',
              '${matches.length} word matches'),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => TopicWordsScreen(topic: t))),
        ));
      }
    }
    for (final Conversation c in conversations) {
      if (hit(c.titleAr) || hit(c.titleEn)) {
        out.add(_resultTile(
          icon: Icons.forum_rounded,
          color: AppColors.coral,
          title: tr(c.titleAr, c.titleEn),
          subtitle: tr('محادثة', 'Conversation'),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => ConversationDetailScreen(conversation: c))),
        ));
      }
    }
    return out;
  }

  Widget _resultTile({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        onTap: onTap,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: <Widget>[
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
