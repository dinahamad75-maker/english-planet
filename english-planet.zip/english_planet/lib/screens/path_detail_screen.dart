import 'package:flutter/material.dart';

import '../content/conversations.dart';
import '../content/grammar.dart';
import '../content/phonics.dart';
import '../content/vocabulary.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'conversations_screen.dart';
import 'lesson_screen.dart';
import 'phonics_screen.dart';
import 'vocabulary_screen.dart';

/// One learning path: an ordered sequence of real content items.
class PathDetailScreen extends StatelessWidget {
  const PathDetailScreen({super.key, required this.path});

  final LearningPath path;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(path.titleAr, path.titleEn)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: <Color>[
                  path.color,
                  path.color.withValues(alpha: 0.7),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Icon(path.icon, color: Colors.white, size: 34),
                const SizedBox(height: 10),
                Text(
                  tr(path.titleAr, path.titleEn),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  path.descAr,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.92),
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${path.cefr} • ${tr('${path.items.length} عناصر', '${path.items.length} items')}',
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SectionHeader(tr('خطوات المسار', 'Path steps')),
          const SizedBox(height: 12),
          ...List<Widget>.generate(path.items.length, (int i) {
            final PathItem item = path.items[i];
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Entrance(
                index: i,
                child: _pathItemCard(context, i, item),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _pathItemCard(BuildContext context, int index, PathItem item) {
    String title;
    String subtitle;
    IconData icon;
    bool done = false;
    VoidCallback? onTap;

    switch (item.kind) {
      case PathItemKind.grammar:
        final Lesson? l = grammarById(item.refId);
        if (l == null) return const SizedBox.shrink();
        title = tr(l.titleAr, l.titleEn);
        subtitle = tr('درس قواعد • ${l.minutes} دقائق',
            'Grammar lesson • ${l.minutes} min');
        icon = Icons.menu_book_rounded;
        done = appState.isLessonDone(l.id);
        onTap = () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => LessonScreen(lesson: l)));
      case PathItemKind.vocabulary:
        final VocabTopic? t = vocabTopicById(item.refId);
        if (t == null) return const SizedBox.shrink();
        title = tr(t.titleAr, t.titleEn);
        subtitle = tr('كلمات • ${t.words.length} كلمة',
            'Vocabulary • ${t.words.length} words');
        icon = t.icon;
        onTap = () => Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => TopicWordsScreen(topic: t)));
      case PathItemKind.phonics:
        final PhonicsSection? s = phonicsById(item.refId);
        if (s == null) return const SizedBox.shrink();
        title = tr(s.titleAr, s.titleEn);
        subtitle = tr('نطق وقراءة • ${s.items.length} عناصر',
            'Phonics • ${s.items.length} items');
        icon = Icons.record_voice_over_rounded;
        onTap = () => Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => PhonicsSectionScreen(section: s)));
      case PathItemKind.conversation:
        final Conversation? c = conversationById(item.refId);
        if (c == null) return const SizedBox.shrink();
        title = tr(c.titleAr, c.titleEn);
        subtitle = tr('محادثة • ${c.lines.length} جمل',
            'Conversation • ${c.lines.length} lines');
        icon = Icons.forum_rounded;
        onTap = () => Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => ConversationDetailScreen(conversation: c)));
    }

    return AppCard(
      onTap: onTap,
      child: Row(
        children: <Widget>[
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: done ? AppColors.mint : path.color.withValues(alpha: 0.14),
              shape: BoxShape.circle,
            ),
            child: done
                ? const Icon(Icons.check_rounded,
                    color: Colors.white, size: 20)
                : Text(
                    '${index + 1}',
                    style: TextStyle(
                        color: path.color, fontWeight: FontWeight.w900),
                  ),
          ),
          const SizedBox(width: 14),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: path.color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: path.color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
