import 'package:flutter/material.dart';

import '../content/phonics.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../services/tts.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

/// Phonics & Reading: letter sounds and patterns, all tap-to-hear.
class PhonicsScreen extends StatelessWidget {
  const PhonicsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('الفونكس والقراءة', 'Phonics & Reading'))),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: phonicsSections.length,
        separatorBuilder: (_, __) => const SizedBox(height: 14),
        itemBuilder: (BuildContext context, int i) {
          final PhonicsSection s = phonicsSections[i];
          return Entrance(
            index: i,
            child: AppCard(
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => PhonicsSectionScreen(section: s))),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: AppColors.mint.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.record_voice_over_rounded,
                        color: AppColors.mint),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(tr(s.titleAr, s.titleEn),
                            style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 4),
                        Text(
                          tr('${s.items.length} عناصر للتدريب',
                              '${s.items.length} practice items'),
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      color: Theme.of(context).textTheme.bodyMedium?.color),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class PhonicsSectionScreen extends StatelessWidget {
  const PhonicsSectionScreen({super.key, required this.section});

  final PhonicsSection section;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(section.titleAr, section.titleEn))),
      body: GridView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: section.items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.95,
        ),
        itemBuilder: (BuildContext context, int i) {
          final PhonicsItem item = section.items[i];
          return Entrance(
            index: i,
            child: AppCard(
              onTap: () => TtsService.instance.speak(item.exampleEn),
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          item.text,
                          style: const TextStyle(
                            color: AppColors.navy,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const Icon(Icons.volume_up_rounded,
                          color: AppColors.mint, size: 20),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Expanded(
                    child: Text(
                      item.soundAr,
                      style: Theme.of(context).textTheme.bodyMedium,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.mintSoft,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${item.exampleEn} • ${item.exampleAr}',
                      style: const TextStyle(
                        color: AppColors.navy,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
