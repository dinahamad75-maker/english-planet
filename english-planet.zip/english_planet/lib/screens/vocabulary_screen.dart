import 'package:flutter/material.dart';

import '../content/vocabulary.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../services/tts.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

/// Vocabulary topics list.
class VocabularyScreen extends StatelessWidget {
  const VocabularyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('عالم الكلمات', 'Vocabulary World'))),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: vocabTopics.length,
        separatorBuilder: (_, __) => const SizedBox(height: 14),
        itemBuilder: (BuildContext context, int i) {
          final VocabTopic topic = vocabTopics[i];
          return Entrance(
            index: i,
            child: AppCard(
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => TopicWordsScreen(topic: topic))),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: topic.color.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(topic.icon, color: topic.color),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(tr(topic.titleAr, topic.titleEn),
                            style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 4),
                        Text(
                          tr('${topic.words.length} كلمات',
                              '${topic.words.length} words'),
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      color: Theme.of(context).textTheme.bodyMedium?.color),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Words inside one topic, with tap-to-hear pronunciation and favorites.
class TopicWordsScreen extends StatelessWidget {
  const TopicWordsScreen({super.key, required this.topic});

  final VocabTopic topic;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(topic.titleAr, topic.titleEn))),
      body: ListenableBuilder(
        listenable: appState,
        builder: (BuildContext context, _) {
          return ListView.separated(
            padding: const EdgeInsets.all(20),
            itemCount: topic.words.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (BuildContext context, int i) {
              final VocabWord w = topic.words[i];
              final bool fav = appState.isFavorite(w.key);
              return Entrance(
                index: i,
                child: AppCard(
                  onTap: () => TtsService.instance.speak(w.en),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  w.en,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleMedium
                                      ?.copyWith(fontSize: 18),
                                ),
                                Text(
                                  w.phonetic,
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(color: AppColors.sky),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            tooltip: tr('استمعي للنطق', 'Listen'),
                            onPressed: () => TtsService.instance.speak(w.en),
                            icon: const Icon(Icons.volume_up_rounded,
                                color: AppColors.sky),
                          ),
                          IconButton(
                            tooltip: tr('حفظ في المفضلة', 'Save to favorites'),
                            onPressed: () => appState.toggleFavorite(w.key),
                            icon: Icon(
                              fav
                                  ? Icons.favorite_rounded
                                  : Icons.favorite_border_rounded,
                              color: fav ? AppColors.coral : null,
                            ),
                          ),
                        ],
                      ),
                      Text(
                        w.ar,
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(color: AppColors.coral),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.skySoft.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(w.exampleEn,
                                style:
                                    Theme.of(context).textTheme.bodyLarge),
                            const SizedBox(height: 2),
                            Text(w.exampleAr,
                                style:
                                    Theme.of(context).textTheme.bodyMedium),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
