import 'package:flutter/material.dart';

import '../content/daily.dart';
import '../content/grammar.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/mascot.dart';
import 'conversations_screen.dart';
import 'grammar_screen.dart';
import 'lesson_screen.dart';
import 'phonics_screen.dart';
import 'search_screen.dart';
import 'vocabulary_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Roll streak and daily counters once per app open.
    WidgetsBinding.instance
        .addPostFrameCallback((_) => appState.touchActivity());
  }

  int get _dayIndex {
    final DateTime now = DateTime.now();
    return DateTime(now.year, now.month, now.day)
        .difference(DateTime(now.year, 1, 1))
        .inDays;
  }

  @override
  Widget build(BuildContext context) {
    final DailyItem word = dailyWords[_dayIndex % dailyWords.length];
    final DailyItem phrase = dailyPhrases[_dayIndex % dailyPhrases.length];
    final DailyItem challenge =
        dailyChallenges[_dayIndex % dailyChallenges.length];
    final Lesson next = _nextLesson();

    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: appState,
          builder: (BuildContext context, _) {
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
              children: <Widget>[
                Entrance(index: 0, child: _header(context)),
                const SizedBox(height: 20),
                Entrance(index: 1, child: _goalCard(context)),
                const SizedBox(height: 16),
                Entrance(index: 2, child: _continueCard(context, next)),
                const SizedBox(height: 20),
                Entrance(
                  index: 3,
                  child: SectionHeader(tr('النهارده في كوكبك', 'Today on your planet')),
                ),
                const SizedBox(height: 12),
                Entrance(index: 4, child: _dailyCard(context, word, phrase, challenge)),
                const SizedBox(height: 20),
                Entrance(
                  index: 5,
                  child: SectionHeader(tr('المهارات', 'Skills')),
                ),
                const SizedBox(height: 12),
                Entrance(index: 6, child: _skillsGrid(context)),
              ],
            );
          },
        ),
      ),
    );
  }

  Lesson _nextLesson() {
    for (final Lesson l in grammarLessons) {
      if (!appState.isLessonDone(l.id)) return l;
    }
    return grammarLessons.last;
  }

  Widget _header(BuildContext context) {
    final String name =
        appState.userName.isEmpty ? tr('يا بطلة', 'learner') : appState.userName;
    return Row(
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                '${tr('صباح الخير', 'Good morning')}, $name',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 4),
              Row(
                children: <Widget>[
                  const Icon(Icons.local_fire_department_rounded,
                      color: AppColors.coral, size: 18),
                  const SizedBox(width: 4),
                  Text(
                    tr('${appState.streak} يوم متواصل',
                        '${appState.streak}-day streak'),
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(width: 12),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.skySoft,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      appState.level,
                      style: const TextStyle(
                        color: AppColors.navy,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        IconButton(
          tooltip: tr('بحث', 'Search'),
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const SearchScreen()),
          ),
          icon: const Icon(Icons.search_rounded, size: 26),
        ),
      ],
    );
  }

  Widget _goalCard(BuildContext context) {
    final double p = appState.dailyGoalProgress;
    return AppCard(
      child: Row(
        children: <Widget>[
          GoalRing(
            progress: p,
            child: Text(
              '${(p * 100).round()}%',
              style: const TextStyle(
                  fontWeight: FontWeight.w900, color: AppColors.navy),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(tr('هدفك اليومي', 'Daily goal'),
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  tr(
                    'خلّصتي ${appState.lessonsToday} من ${appState.dailyGoal} دروس النهارده',
                    '${appState.lessonsToday} of ${appState.dailyGoal} lessons done today',
                  ),
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _continueCard(BuildContext context, Lesson next) {
    return Container(
      decoration: BoxDecoration(
        gradient: AppColors.heroGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        boxShadow: AppTheme.softShadow(AppColors.navy),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
                builder: (_) => LessonScreen(lesson: next)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: <Widget>[
                const PlanetMascot(size: 72),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        tr('كمّلي التعلم', 'Continue learning'),
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.85),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        tr(next.titleAr, next.titleEn),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: <Widget>[
                          const Icon(Icons.schedule_rounded,
                              color: AppColors.yellow, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            tr('${next.minutes} دقائق', '${next.minutes} min'),
                            style: const TextStyle(
                                color: AppColors.yellow,
                                fontWeight: FontWeight.w700,
                                fontSize: 13),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.play_circle_fill_rounded,
                    color: Colors.white, size: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _dailyCard(BuildContext context, DailyItem word, DailyItem phrase,
      DailyItem challenge) {
    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: <Widget>[
          _dailyRow(
            context,
            icon: Icons.lightbulb_rounded,
            color: AppColors.yellow,
            title: tr('كلمة اليوم', 'Word of the day'),
            main: word.en,
            sub: '${word.ar} • ${word.noteAr}',
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),
          _dailyRow(
            context,
            icon: Icons.format_quote_rounded,
            color: AppColors.sky,
            title: tr('عبارة اليوم', 'Phrase of the day'),
            main: phrase.en,
            sub: '${phrase.ar} • ${phrase.noteAr}',
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),
          _dailyRow(
            context,
            icon: Icons.emoji_events_rounded,
            color: AppColors.coral,
            title: tr('تحدي اليوم', 'Daily challenge'),
            main: tr(challenge.ar, challenge.en),
            sub: challenge.noteAr,
          ),
        ],
      ),
    );
  }

  Widget _dailyRow(
    BuildContext context, {
    required IconData icon,
    required Color color,
    required String title,
    required String main,
    required String sub,
  }) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title,
                    style: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(main,
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 2),
                Text(sub, style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _skillsGrid(BuildContext context) {
    final List<_Skill> skills = <_Skill>[
      _Skill(tr('القواعد', 'Grammar'), Icons.menu_book_rounded,
          AppColors.sky, () => _open(const GrammarScreen())),
      _Skill(tr('الكلمات', 'Vocabulary'), Icons.abc_rounded,
          AppColors.yellow, () => _open(const VocabularyScreen())),
      _Skill(tr('القراءة والنطق', 'Phonics'), Icons.record_voice_over_rounded,
          AppColors.mint, () => _open(const PhonicsScreen())),
      _Skill(tr('المحادثة', 'Speaking'), Icons.forum_rounded,
          AppColors.coral, () => _open(const ConversationsScreen())),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: skills.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.9,
      ),
      itemBuilder: (BuildContext context, int i) {
        final _Skill s = skills[i];
        return AppCard(
          onTap: s.onTap,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: <Widget>[
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: s.color.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(s.icon, color: s.color),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(s.title,
                    style: Theme.of(context).textTheme.titleMedium,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
        );
      },
    );
  }

  void _open(Widget screen) {
    Navigator.of(context)
        .push(MaterialPageRoute<void>(builder: (_) => screen));
  }
}

class _Skill {
  _Skill(this.title, this.icon, this.color, this.onTap);
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
}
