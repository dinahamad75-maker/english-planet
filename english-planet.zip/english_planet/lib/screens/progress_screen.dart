import 'package:flutter/material.dart';

import '../content/grammar.dart';
import '../content/vocabulary.dart';
import '../l10n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

/// Student progress dashboard: streak, completed lessons, quiz scores,
/// favorites and achievement badges.
class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('تقدمي', 'My Progress'))),
      body: ListenableBuilder(
        listenable: appState,
        builder: (BuildContext context, _) {
          return ListView(
            padding: const EdgeInsets.all(20),
            children: <Widget>[
              StatChip(
                icon: Icons.local_fire_department_rounded,
                label: tr('أيام متواصلة', 'Day streak'),
                value: '${appState.streak}',
                color: AppColors.coral,
              ),
              const SizedBox(height: 12),
              StatChip(
                icon: Icons.check_circle_rounded,
                label: tr('دروس مكتملة', 'Lessons done'),
                value:
                    '${appState.completedLessons.length}/${grammarLessons.length}',
                color: AppColors.mint,
              ),
              const SizedBox(height: 12),
              StatChip(
                icon: Icons.favorite_rounded,
                label: tr('كلمات محفوظة', 'Saved words'),
                value: '${appState.favoriteWords.length}',
                color: AppColors.sky,
              ),
              const SizedBox(height: 24),
              SectionHeader(tr('نتائج الاختبارات', 'Quiz scores')),
              const SizedBox(height: 12),
              ..._quizScores(context),
              const SizedBox(height: 24),
              SectionHeader(tr('الأوسمة', 'Badges')),
              const SizedBox(height: 12),
              _badges(context),
              const SizedBox(height: 24),
              SectionHeader(tr('كلماتي المفضلة', 'My favorite words')),
              const SizedBox(height: 12),
              _favorites(context),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _quizScores(BuildContext context) {
    final List<Widget> rows = <Widget>[];
    for (final Lesson l in grammarLessons) {
      final int? score = appState.quizScore(l.quizId);
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: AppCard(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Text(tr(l.titleAr, l.titleEn),
                      style: Theme.of(context).textTheme.titleMedium),
                ),
                if (score == null)
                  Text(tr('لسه', 'Not yet'),
                      style: Theme.of(context).textTheme.bodyMedium)
                else
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: score >= 60
                          ? AppColors.mintSoft
                          : AppColors.coralSoft,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '$score%',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: score >= 60
                            ? AppColors.mint
                            : AppColors.coral,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }
    return rows;
  }

  Widget _badges(BuildContext context) {
    final List<AppBadge> earned = appState.earnedBadges;
    final List<(AppBadge, String, String, IconData, Color)> all =
        <(AppBadge, String, String, IconData, Color)>[
      (AppBadge.firstLesson, tr('أول خطوة', 'First step'),
          tr('أكملتي أول درس', 'Finish your first lesson'),
          Icons.rocket_launch_rounded, AppColors.sky),
      (AppBadge.fiveLessons, tr('مثابرة', 'Persistent'),
          tr('5 دروس مكتملة', '5 lessons done'),
          Icons.star_rounded, AppColors.yellow),
      (AppBadge.tenLessons, tr('نجمة', 'Star'),
          tr('10 دروس مكتملة', '10 lessons done'),
          Icons.stars_rounded, AppColors.coral),
      (AppBadge.streak3, tr('3 أيام نار', '3-day fire'),
          tr('3 أيام متواصلة', '3-day streak'),
          Icons.local_fire_department_rounded, AppColors.coral),
      (AppBadge.streak7, tr('أسبوع كامل', 'Full week'),
          tr('7 أيام متواصلة', '7-day streak'),
          Icons.whatshot_rounded, AppColors.yellow),
      (AppBadge.perfectQuiz, tr('العلامة الكاملة', 'Perfect score'),
          tr('100% في اختبار', '100% on a quiz'),
          Icons.emoji_events_rounded, AppColors.mint),
      (AppBadge.collector, tr('جامعة الكلمات', 'Word collector'),
          tr('10 كلمات محفوظة', '10 saved words'),
          Icons.favorite_rounded, AppColors.sky),
    ];
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: all.map(((AppBadge, String, String, IconData, Color) b) {
        final bool has = earned.contains(b.$1);
        return Container(
          width: (MediaQuery.of(context).size.width - 60) / 2,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: has
                ? b.$5.withValues(alpha: 0.12)
                : Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(AppTheme.radiusMd),
            border: Border.all(
              color: has
                  ? b.$5.withValues(alpha: 0.4)
                  : Colors.grey.withValues(alpha: 0.15),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(b.$4,
                  color: has ? b.$5 : Colors.grey.withValues(alpha: 0.4),
                  size: 30),
              const SizedBox(height: 8),
              Text(
                b.$2,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: has
                      ? Theme.of(context).textTheme.bodyLarge?.color
                      : Colors.grey,
                ),
              ),
              Text(
                b.$3,
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(fontSize: 12),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _favorites(BuildContext context) {
    final List<VocabWord> favs = <VocabWord>[
      for (final VocabTopic t in vocabTopics)
        ...t.words.where((VocabWord w) => appState.isFavorite(w.key)),
    ];
    if (favs.isEmpty) {
      return AppCard(
        child: Text(
          tr('لسه محفظتيش كلمات. دوسي على القلب جنب أي كلمة عشان تضيفيها هنا ❤️',
              'No saved words yet. Tap the heart next to any word to add it here ❤️'),
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      );
    }
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: favs
          .map((VocabWord w) => Chip(
                label: Text('${w.en} • ${w.ar}'),
                backgroundColor: AppColors.skySoft,
              ))
          .toList(),
    );
  }
}
