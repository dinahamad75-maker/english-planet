import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'conversations_screen.dart';
import 'grammar_screen.dart';
import 'phonics_screen.dart';
import 'vocabulary_screen.dart';

/// Skills hub: Grammar Academy, Vocabulary, Phonics & Reading, Conversations.
class SkillsScreen extends StatelessWidget {
  const SkillsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<_Hub> items = <_Hub>[
      _Hub(
        tr('أكاديمية القواعد', 'Grammar Academy'),
        tr('دروس مرتبة من الأسهل للأصعب مع تمارين تفاعلية',
            'Lessons ordered from easy to hard with interactive exercises'),
        Icons.menu_book_rounded,
        AppColors.sky,
        const GrammarScreen(),
      ),
      _Hub(
        tr('عالم الكلمات', 'Vocabulary World'),
        tr('كلمات مرتبة حسب الموضوع مع النطق والأمثلة',
            'Words organized by topic with pronunciation and examples'),
        Icons.abc_rounded,
        AppColors.yellow,
        const VocabularyScreen(),
      ),
      _Hub(
        tr('الفونكس والقراءة', 'Phonics & Reading'),
        tr('الحروف والأصوات وقواعد النطق خطوة بخطوة',
            'Letters, sounds and pronunciation step by step'),
        Icons.record_voice_over_rounded,
        AppColors.mint,
        const PhonicsScreen(),
      ),
      _Hub(
        tr('المحادثة اليومية', 'Everyday Speaking'),
        tr('حوارات حقيقية من مواقف الحياة مع الترجمة',
            'Real-life dialogues with translation'),
        Icons.forum_rounded,
        AppColors.coral,
        const ConversationsScreen(),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: Text(tr('المهارات', 'Skills'))),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 14),
        itemBuilder: (BuildContext context, int i) {
          final _Hub h = items[i];
          return Entrance(
            index: i,
            child: AppCard(
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => h.screen)),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: h.color.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(h.icon, color: h.color, size: 28),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(h.title,
                            style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 4),
                        Text(h.subtitle,
                            style: Theme.of(context).textTheme.bodyMedium),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      color:
                          Theme.of(context).textTheme.bodyMedium?.color),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Hub {
  _Hub(this.title, this.subtitle, this.icon, this.color, this.screen);
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final Widget screen;
}
