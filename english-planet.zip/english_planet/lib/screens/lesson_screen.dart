import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'quiz_screen.dart';

/// A grammar lesson: Arabic explanation, bilingual examples, notes,
/// common mistakes, then the lesson quiz.
class LessonScreen extends StatelessWidget {
  const LessonScreen({super.key, required this.lesson});

  final Lesson lesson;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(lesson.titleAr, lesson.titleEn))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: <Widget>[
          Entrance(
            index: 0,
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: AppColors.heroGradient,
                borderRadius: BorderRadius.circular(AppTheme.radiusLg),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.yellow,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${lesson.level} • ${tr('${lesson.minutes} دقائق', '${lesson.minutes} min')}',
                      style: const TextStyle(
                        color: AppColors.navy,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    tr(lesson.titleAr, lesson.titleEn),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    lesson.introAr,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.92),
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Entrance(
            index: 1,
            child: SectionHeader(tr('الشرح', 'Explanation')),
          ),
          const SizedBox(height: 10),
          Entrance(
            index: 2,
            child: AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List<Widget>.generate(
                  lesson.explanationAr.length,
                  (int i) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          width: 24,
                          height: 24,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppColors.sky.withValues(alpha: 0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${i + 1}',
                            style: const TextStyle(
                              color: AppColors.sky,
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            lesson.explanationAr[i],
                            style: Theme.of(context).textTheme.bodyLarge,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Entrance(
            index: 3,
            child: SectionHeader(tr('أمثلة', 'Examples')),
          ),
          const SizedBox(height: 10),
          Entrance(
            index: 4,
            child: AppCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: List<Widget>.generate(
                  lesson.examples.length,
                  (int i) => Column(
                    children: <Widget>[
                      if (i > 0)
                        const Divider(height: 1, indent: 16, endIndent: 16),
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: const BoxDecoration(
                                    color: AppColors.mint,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    lesson.examples[i].en,
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyLarge
                                        ?.copyWith(fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding:
                                  const EdgeInsetsDirectional.only(start: 16),
                              child: Text(
                                lesson.examples[i].ar,
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Entrance(
            index: 5,
            child: SectionHeader(tr('ملاحظات مهمة', 'Key notes')),
          ),
          const SizedBox(height: 10),
          Entrance(
            index: 6,
            child: AppCard(
              color: AppColors.yellowSoft,
              child: Column(
                children: List<Widget>.generate(
                  lesson.notesAr.length,
                  (int i) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Icon(Icons.lightbulb_rounded,
                            color: AppColors.yellow, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            lesson.notesAr[i],
                            style: const TextStyle(
                                color: AppColors.navy, height: 1.55),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Entrance(
            index: 7,
            child: SectionHeader(tr('أخطاء شائعة', 'Common mistakes')),
          ),
          const SizedBox(height: 10),
          Entrance(
            index: 8,
            child: AppCard(
              color: AppColors.coralSoft,
              child: Column(
                children: List<Widget>.generate(
                  lesson.mistakes.length,
                  (int i) {
                    final CommonMistake m = lesson.mistakes[i];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              const Icon(Icons.close_rounded,
                                  color: AppColors.coral, size: 18),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  m.wrong,
                                  style: const TextStyle(
                                    color: AppColors.coral,
                                    fontWeight: FontWeight.w700,
                                    decoration: TextDecoration.lineThrough,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: <Widget>[
                              const Icon(Icons.check_rounded,
                                  color: AppColors.mint, size: 18),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  m.right,
                                  style: const TextStyle(
                                    color: AppColors.navy,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            m.noteAr,
                            style: TextStyle(
                              color: AppColors.navy.withValues(alpha: 0.7),
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Entrance(
            index: 9,
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                      builder: (_) => QuizScreen(lesson: lesson)),
                ),
                icon: const Icon(Icons.quiz_rounded),
                label: Text(
                  tr('ابدئي اختبار الدرس (${lesson.quiz.length} أسئلة)',
                      'Start the lesson quiz (${lesson.quiz.length} questions)'),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
