import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

/// Interactive quiz engine. Supports multiple choice, true/false,
/// fill-in-the-blank (with options) and arrange-the-words questions.
/// Immediate feedback with an Arabic explanation, a final score, and a
/// retry mode that repeats only the questions answered incorrectly.
class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, required this.lesson, this.retryQuestions});

  final Lesson lesson;

  /// When set, the quiz runs only these questions (retry mode).
  final List<QuizQuestion>? retryQuestions;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late final List<QuizQuestion> _questions =
      widget.retryQuestions ?? widget.lesson.quiz;
  int _index = 0;
  int _correct = 0;
  int? _selected; // chosen option index
  List<String> _arrangePicked = <String>[];
  List<String> _arrangeBank = <String>[];
  bool _answered = false;
  bool _lastCorrect = false;
  final List<QuizQuestion> _wrong = <QuizQuestion>[];
  bool _finished = false;

  QuizQuestion get _q => _questions[_index];

  @override
  void initState() {
    super.initState();
    if (_q.type == QuestionType.arrange) {
      _arrangeBank = List<String>.from(_q.options);
    }
  }

  void _checkArrange() {
    final bool ok = _arrangePicked.length == _q.arrangeAnswer.length &&
        List<int>.generate(_arrangePicked.length, (int i) => i)
            .every((int i) => _arrangePicked[i] == _q.arrangeAnswer[i]);
    _submit(ok);
  }

  void _submit(bool correct) {
    setState(() {
      _answered = true;
      _lastCorrect = correct;
      if (correct) {
        _correct += 1;
      } else {
        _wrong.add(_q);
      }
    });
  }

  void _next() {
    if (_index + 1 >= _questions.length) {
      final int percent = ((_correct / _questions.length) * 100).round();
      appState.recordQuizScore(widget.lesson.quizId, percent);
      if (percent >= 60) {
        appState.completeLesson(widget.lesson.id);
      }
      setState(() => _finished = true);
      return;
    }
    setState(() {
      _index += 1;
      _selected = null;
      _answered = false;
      _arrangePicked = <String>[];
      _arrangeBank = _q.type == QuestionType.arrange
          ? List<String>.from(_q.options)
          : <String>[];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('اختبار: ${widget.lesson.titleAr}',
            'Quiz: ${widget.lesson.titleEn}')),
      ),
      body: SafeArea(
        child: _finished ? _result(context) : _question(context),
      ),
    );
  }

  // ---------------- question view ----------------

  Widget _question(BuildContext context) {
    final QuizQuestion q = _q;
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: (_index + (_answered ? 1 : 0)) / _questions.length,
                    minHeight: 8,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '${_index + 1}/${_questions.length}',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(q.promptAr, style: Theme.of(context).textTheme.titleMedium),
          if (q.promptEn.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.skySoft.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                q.promptEn,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppColors.navy,
                  height: 1.5,
                ),
              ),
            ),
          ],
          const SizedBox(height: 20),
          Expanded(child: _answerArea(q)),
          if (_answered) _feedback(q),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _answered ? _next : _submitIfReady(q),
              child: Text(
                _answered
                    ? tr('التالي', 'Next')
                    : tr('تأكيد الإجابة', 'Check answer'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  VoidCallback? _submitIfReady(QuizQuestion q) {
    if (q.type == QuestionType.arrange) {
      if (_arrangePicked.length == q.arrangeAnswer.length) {
        return _checkArrange;
      }
      return null;
    }
    if (_selected == null) return null;
    return () => _submit(_selected == q.answerIndex);
  }

  Widget _answerArea(QuizQuestion q) {
    if (q.type == QuestionType.arrange) return _arrangeArea(q);
    final List<String> options = q.type == QuestionType.trueFalse
        ? <String>['True', 'False']
        : q.options;
    return ListView.separated(
      itemCount: options.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (BuildContext context, int i) {
        final bool chosen = _selected == i;
        Color? bg;
        Color border = AppColors.sky.withValues(alpha: 0.25);
        if (_answered) {
          if (i == q.answerIndex) {
            bg = AppColors.mintSoft;
            border = AppColors.mint;
          } else if (chosen) {
            bg = AppColors.coralSoft;
            border = AppColors.coral;
          }
        } else if (chosen) {
          bg = AppColors.skySoft;
          border = AppColors.sky;
        }
        return GestureDetector(
          onTap: _answered ? null : () => setState(() => _selected = i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: border, width: 1.6),
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    options[i],
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                ),
                if (_answered && i == q.answerIndex)
                  const Icon(Icons.check_circle_rounded,
                      color: AppColors.mint)
                else if (_answered && chosen)
                  const Icon(Icons.cancel_rounded, color: AppColors.coral),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _arrangeArea(QuizQuestion q) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
          constraints: const BoxConstraints(minHeight: 70),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppColors.skySoft.withValues(alpha: 0.4),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.sky.withValues(alpha: 0.3)),
          ),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _arrangePicked
                .map((String w) => _wordChip(
                      w,
                      onTap: _answered
                          ? null
                          : () => setState(() {
                                _arrangePicked.remove(w);
                                _arrangeBank.add(w);
                              }),
                    ))
                .toList(),
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _arrangeBank
              .map((String w) => _wordChip(
                    w,
                    bank: true,
                    onTap: _answered
                        ? null
                        : () => setState(() {
                              _arrangeBank.remove(w);
                              _arrangePicked.add(w);
                            }),
                  ))
              .toList(),
        ),
      ],
    );
  }

  Widget _wordChip(String word, {bool bank = false, VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: bank ? Colors.white : AppColors.sky,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: bank ? AppColors.sky.withValues(alpha: 0.4) : AppColors.sky),
        ),
        child: Text(
          word,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: bank ? AppColors.navy : Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _feedback(QuizQuestion q) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _lastCorrect ? AppColors.mintSoft : AppColors.coralSoft,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(
            _lastCorrect
                ? Icons.celebration_rounded
                : Icons.info_rounded,
            color: _lastCorrect ? AppColors.mint : AppColors.coral,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  _lastCorrect ? tr('أحسنتِ! 🎉', 'Well done! 🎉') : tr('ليست الإجابة الصحيحة', 'Not quite'),
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: _lastCorrect ? AppColors.mint : AppColors.coral,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  q.explanationAr,
                  style:
                      const TextStyle(color: AppColors.navy, height: 1.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------- result view ----------------

  Widget _result(BuildContext context) {
    final int percent = ((_correct / _questions.length) * 100).round();
    final bool passed = percent >= 60;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: passed ? AppColors.mintSoft : AppColors.yellowSoft,
              ),
              child: Center(
                child: Text(
                  '$percent%',
                  style: TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                    color: passed ? AppColors.mint : AppColors.yellow,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              passed
                  ? tr('ممتاز! عديتِ الاختبار 🎉', 'Great job! You passed 🎉')
                  : tr('محاولة كويسة! راجعي الدرس وجربي تاني 💪',
                      'Good try! Review the lesson and try again 💪'),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              tr('أجبتِ صح على $_correct من ${_questions.length} أسئلة',
                  'You answered $_correct of ${_questions.length} correctly'),
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            if (passed) ...<Widget>[
              const SizedBox(height: 8),
              Text(
                tr('الدرس اتعلّم كمكتمل ✅', 'Lesson marked as complete ✅'),
                style: const TextStyle(
                    color: AppColors.mint, fontWeight: FontWeight.w700),
              ),
            ],
            const SizedBox(height: 24),
            if (_wrong.isNotEmpty)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute<void>(
                      builder: (_) => QuizScreen(
                        lesson: widget.lesson,
                        retryQuestions: List<QuizQuestion>.from(_wrong),
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.replay_rounded),
                  label: Text(
                    tr('إعادة الأسئلة الغلط (${_wrong.length})',
                        'Retry wrong questions (${_wrong.length})'),
                  ),
                ),
              ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(64, 52),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: Text(tr('رجوع', 'Back')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
