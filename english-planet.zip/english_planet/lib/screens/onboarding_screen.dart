import 'package:flutter/material.dart';

import '../l10n/strings.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/mascot.dart';
import 'main_shell.dart';

/// Three-page onboarding: welcome, language choice, level choice, then start.
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pages = PageController();
  int _page = 0;

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    await appState.completeOnboarding();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => const MainShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Expanded(
              child: PageView(
                controller: _pages,
                onPageChanged: (int i) => setState(() => _page = i),
                children: <Widget>[
                  _welcomePage(),
                  _languagePage(),
                  _levelPage(),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
              child: Column(
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List<Widget>.generate(
                      3,
                      (int i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: _page == i ? 26 : 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: _page == i
                              ? AppColors.sky
                              : AppColors.sky.withValues(alpha: 0.25),
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (_page < 2) {
                          _pages.nextPage(
                            duration: const Duration(milliseconds: 320),
                            curve: Curves.easeOut,
                          );
                        } else {
                          _finish();
                        }
                      },
                      child: Text(
                        _page < 2
                            ? tr('التالي', 'Next')
                            : tr('ابدأ التعلم', 'Start Learning'),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _welcomePage() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          const PlanetMascot(size: 170, animate: true),
          const SizedBox(height: 28),
          Text(
            tr('أهلًا بيك في كوكب التأسيس!', 'Welcome to English Planet!'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 12),
          Text(
            tr(
              'رحلة ممتعة ومنظمة لتعلم الإنجليزية من الصفر للاحتراف: قواعد، كلمات، نطق، ومحادثات من الحياة اليومية.',
              'A fun, structured journey to learn English from zero to hero: grammar, vocabulary, pronunciation and everyday conversations.',
            ),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }

  Widget _languagePage() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            tr('اختاري لغة التطبيق', 'Choose your language'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            tr('تقدري تغيريها في أي وقت من الإعدادات',
                'You can change it anytime in Settings'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 28),
          _languageCard('ar', 'العربية', 'واجهة عربية بالكامل مع شرح بالعربي'),
          const SizedBox(height: 14),
          _languageCard('en', 'English', 'Full English interface'),
        ],
      ),
    );
  }

  Widget _languageCard(String code, String title, String subtitle) {
    final bool selected = appState.locale.languageCode == code;
    return AppCard(
      onTap: () => setState(() => appState.setLocale(code)),
      color: selected ? AppColors.skySoft : null,
      child: Row(
        children: <Widget>[
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: selected ? AppColors.sky : AppColors.sky.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              Icons.translate_rounded,
              color: selected ? Colors.white : AppColors.sky,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
          if (selected)
            const Icon(Icons.check_circle_rounded, color: AppColors.sky),
        ],
      ),
    );
  }

  Widget _levelPage() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 24),
          Text(
            tr('إيه مستواك الحالي؟', 'What is your current level?'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            tr('مش متأكدة؟ اختاري "مبتدئة تمامًا" والتطبيق هيقترح عليك المسار المناسب',
                'Not sure? Pick "Pre-A1" and the app will suggest the right path'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 24),
          Expanded(
            child: ListView.separated(
              itemCount: AppState.levels.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (BuildContext context, int i) {
                final String lv = AppState.levels[i];
                final bool selected = appState.level == lv;
                final List<String> labels = <String>[
                  tr('مبتدئة تمامًا', 'Complete beginner'),
                  tr('مبتدئة', 'Beginner'),
                  tr('ابتدائي', 'Elementary'),
                  tr('متوسط', 'Intermediate'),
                  tr('فوق المتوسط', 'Upper intermediate'),
                  tr('متقدم', 'Advanced'),
                  tr('احترافي', 'Proficiency'),
                ];
                return AppCard(
                  onTap: () => setState(() => appState.setLevel(lv)),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  color: selected ? AppColors.yellowSoft : null,
                  child: Row(
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: selected
                              ? AppColors.yellow
                              : AppColors.navy.withValues(alpha: 0.07),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          lv,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: selected
                                ? AppColors.navy
                                : Theme.of(context)
                                    .textTheme
                                    .bodyLarge
                                    ?.color,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(labels[i],
                            style: Theme.of(context).textTheme.titleMedium),
                      ),
                      if (selected)
                        const Icon(Icons.check_circle_rounded,
                            color: AppColors.yellow),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
