import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// The friendly English Planet mascot: a smiling sky-blue planet with a
/// coral orbit ring and a tiny yellow star. Fully drawn in code, so the app
/// needs no image assets for its mascot.
class PlanetMascot extends StatelessWidget {
  const PlanetMascot({super.key, this.size = 120, this.animate = false});

  final double size;

  /// When true the mascot floats gently up and down.
  final bool animate;

  @override
  Widget build(BuildContext context) {
    final Widget painter = CustomPaint(
      size: Size.square(size),
      painter: _PlanetPainter(),
    );
    if (!animate) return painter;
    return _Floating(child: painter);
  }
}

class _Floating extends StatefulWidget {
  const _Floating({required this.child});
  final Widget child;

  @override
  State<_Floating> createState() => _FloatingState();
}

class _FloatingState extends State<_Floating>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 3),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (BuildContext context, Widget? child) {
        final double dy = math.sin(_controller.value * math.pi) * -8;
        return Transform.translate(offset: Offset(0, dy), child: child);
      },
      child: widget.child,
    );
  }
}

class _PlanetPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final double w = size.width;
    final Offset center = Offset(w / 2, w / 2);
    final double radius = w * 0.30;

    // Orbit ring (behind the planet).
    final Paint ringPaint = Paint()
      ..color = AppColors.coral
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.035
      ..strokeCap = StrokeCap.round;
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(-0.35);
    canvas.drawOval(
      Rect.fromCenter(center: Offset.zero, width: w * 0.92, height: w * 0.34),
      ringPaint,
    );
    canvas.restore();

    // Planet body.
    final Paint bodyPaint = Paint()
      ..shader = const RadialGradient(
        center: Alignment(-0.35, -0.4),
        radius: 1.1,
        colors: <Color>[Color(0xFF8FD6F3), AppColors.sky, Color(0xFF2E86C1)],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, bodyPaint);

    // Continents.
    final Paint landPaint = Paint()..color = AppColors.mint.withValues(alpha: 0.85);
    canvas.drawCircle(center + Offset(-radius * 0.3, -radius * 0.15), radius * 0.28, landPaint);
    canvas.drawCircle(center + Offset(radius * 0.25, radius * 0.35), radius * 0.2, landPaint);

    // Face.
    final Paint eyePaint = Paint()..color = AppColors.navy;
    final double eyeY = center.dy - radius * 0.05;
    canvas.drawCircle(Offset(center.dx - radius * 0.32, eyeY), w * 0.028, eyePaint);
    canvas.drawCircle(Offset(center.dx + radius * 0.32, eyeY), w * 0.028, eyePaint);

    // Smile.
    final Paint smilePaint = Paint()
      ..color = AppColors.navy
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.022
      ..strokeCap = StrokeCap.round;
    final Rect smileRect = Rect.fromCenter(
      center: Offset(center.dx, center.dy + radius * 0.18),
      width: radius * 0.7,
      height: radius * 0.5,
    );
    canvas.drawArc(smileRect, 0.25, math.pi - 0.5, false, smilePaint);

    // Cheeks.
    final Paint cheekPaint = Paint()..color = AppColors.coral.withValues(alpha: 0.7);
    canvas.drawCircle(Offset(center.dx - radius * 0.52, center.dy + radius * 0.14), w * 0.026, cheekPaint);
    canvas.drawCircle(Offset(center.dx + radius * 0.52, center.dy + radius * 0.14), w * 0.026, cheekPaint);

    // Little star.
    final Paint starPaint = Paint()..color = AppColors.yellow;
    final Offset starCenter = Offset(w * 0.82, w * 0.18);
    final double sr = w * 0.05;
    canvas.drawCircle(starCenter, sr * 0.45, starPaint);
    canvas.drawRect(
      Rect.fromCenter(center: starCenter, width: sr * 0.35, height: sr * 2),
      starPaint,
    );
    canvas.drawRect(
      Rect.fromCenter(center: starCenter, width: sr * 2, height: sr * 0.35),
      starPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
