import 'package:flutter/material.dart';

/// English Planet design system.
/// Brand colors come straight from the brand brief.
class AppColors {
  AppColors._();

  static const Color navy = Color(0xFF172B4D); // Deep Navy
  static const Color sky = Color(0xFF49B7E9); // Sky Blue
  static const Color yellow = Color(0xFFFFC94A); // Sunny Yellow
  static const Color offWhite = Color(0xFFF7FAFC); // Off White
  static const Color coral = Color(0xFFFF817A); // Soft Coral

  static const Color navyLight = Color(0xFF253E66);
  static const Color skySoft = Color(0xFFE3F3FC);
  static const Color yellowSoft = Color(0xFFFFF4DB);
  static const Color coralSoft = Color(0xFFFFE9E7);
  static const Color mint = Color(0xFF4BC9A8);
  static const Color mintSoft = Color(0xFFE2F7F0);
  static const Color inkSoft = Color(0xFF5A6B85);

  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: <Color>[navy, Color(0xFF1F4470), Color(0xFF2E6EA6)],
  );

  static const LinearGradient skyGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: <Color>[sky, Color(0xFF7FCDEF)],
  );
}

class AppTheme {
  AppTheme._();

  static const double radiusMd = 18;
  static const double radiusLg = 24;

  static List<BoxShadow> softShadow([Color? tint]) => <BoxShadow>[
        BoxShadow(
          color: (tint ?? AppColors.navy).withValues(alpha: 0.08),
          blurRadius: 18,
          offset: const Offset(0, 8),
        ),
      ];

  static ThemeData light() => _base(Brightness.light);
  static ThemeData dark() => _base(Brightness.dark);

  static ThemeData _base(Brightness brightness) {
    final bool isDark = brightness == Brightness.dark;
    final ColorScheme scheme = ColorScheme.fromSeed(
      seedColor: AppColors.sky,
      brightness: brightness,
      primary: AppColors.sky,
      secondary: AppColors.yellow,
      surface: isDark ? const Color(0xFF101E33) : AppColors.offWhite,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor:
          isDark ? const Color(0xFF0C1727) : AppColors.offWhite,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: isDark ? Colors.white : AppColors.navy,
          fontSize: 20,
          fontWeight: FontWeight.w800,
        ),
        iconTheme: IconThemeData(color: isDark ? Colors.white : AppColors.navy),
      ),
      cardTheme: CardThemeData(
        color: isDark ? const Color(0xFF14253E) : Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: isDark ? const Color(0xFF101E33) : Colors.white,
        indicatorColor: AppColors.sky.withValues(alpha: 0.18),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
        ),
      ),
      textTheme: TextTheme(
        headlineLarge: TextStyle(
          color: isDark ? Colors.white : AppColors.navy,
          fontWeight: FontWeight.w900,
          fontSize: 30,
          height: 1.2,
        ),
        headlineMedium: TextStyle(
          color: isDark ? Colors.white : AppColors.navy,
          fontWeight: FontWeight.w800,
          fontSize: 24,
          height: 1.25,
        ),
        titleLarge: TextStyle(
          color: isDark ? Colors.white : AppColors.navy,
          fontWeight: FontWeight.w800,
          fontSize: 20,
        ),
        titleMedium: TextStyle(
          color: isDark ? Colors.white : AppColors.navy,
          fontWeight: FontWeight.w700,
          fontSize: 16,
        ),
        bodyLarge: TextStyle(
          color: isDark ? const Color(0xFFE6ECF5) : AppColors.navy,
          fontSize: 16,
          height: 1.6,
        ),
        bodyMedium: TextStyle(
          color: isDark ? const Color(0xFFC4D0E0) : AppColors.inkSoft,
          fontSize: 14,
          height: 1.55,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.yellow,
          foregroundColor: AppColors.navy,
          elevation: 0,
          minimumSize: const Size(64, 52),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AppColors.sky,
        linearTrackColor: Color(0xFFDCE8F2),
      ),
      fontFamily: null,
    );
  }
}
