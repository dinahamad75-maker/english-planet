import 'package:flutter/material.dart';

/// Content models. All educational content is data, kept under lib/content/,
/// so new lessons can be added without touching application logic.

enum QuestionType { mcq, trueFalse, fillBlank, arrange }

class QuizQuestion {
  const QuizQuestion({
    required this.type,
    required this.promptAr,
    this.promptEn = '',
    this.options = const <String>[],
    this.answerIndex = 0,
    this.arrangeAnswer = const <String>[],
    required this.explanationAr,
  });

  final QuestionType type;

  /// Instruction shown to the learner (Arabic).
  final String promptAr;

  /// English sentence; for fillBlank it contains `___` as the gap.
  final String promptEn;

  /// Options for mcq / fillBlank. For arrange, the word bank (shuffled).
  final List<String> options;

  /// Correct option index for mcq / trueFalse / fillBlank.
  /// For trueFalse, options are ['True', 'False'].
  final int answerIndex;

  /// Correct word order for arrange questions.
  final List<String> arrangeAnswer;

  final String explanationAr;
}

class LessonExample {
  const LessonExample(this.en, this.ar);
  final String en;
  final String ar;
}

class CommonMistake {
  const CommonMistake(this.wrong, this.right, this.noteAr);
  final String wrong;
  final String right;
  final String noteAr;
}

class Lesson {
  const Lesson({
    required this.id,
    required this.titleEn,
    required this.titleAr,
    required this.level,
    required this.minutes,
    required this.introAr,
    required this.explanationAr,
    required this.examples,
    required this.notesAr,
    required this.mistakes,
    required this.quiz,
  });

  final String id;
  final String titleEn;
  final String titleAr;
  final String level; // CEFR tag
  final int minutes;
  final String introAr;
  final List<String> explanationAr; // Arabic explanation paragraphs
  final List<LessonExample> examples; // English example + Arabic translation
  final List<String> notesAr;
  final List<CommonMistake> mistakes;
  final List<QuizQuestion> quiz;

  String get quizId => 'quiz-$id';
}

class VocabWord {
  const VocabWord({
    required this.en,
    required this.ar,
    required this.phonetic,
    required this.exampleEn,
    required this.exampleAr,
  });

  final String en;
  final String ar;
  final String phonetic;
  final String exampleEn;
  final String exampleAr;

  /// Stable key used for favorites.
  String get key => en.toLowerCase();
}

class VocabTopic {
  const VocabTopic({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.icon,
    required this.color,
    required this.words,
  });

  final String id;
  final String titleAr;
  final String titleEn;
  final IconData icon;
  final Color color;
  final List<VocabWord> words;
}

class PhonicsItem {
  const PhonicsItem(this.text, this.soundAr, this.exampleEn, this.exampleAr);
  final String text; // letter or pattern
  final String soundAr; // how it sounds, explained in Arabic
  final String exampleEn;
  final String exampleAr;
}

class PhonicsSection {
  const PhonicsSection({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.items,
  });

  final String id;
  final String titleAr;
  final String titleEn;
  final List<PhonicsItem> items;
}

class ConversationLine {
  const ConversationLine(this.speaker, this.en, this.ar);
  final String speaker;
  final String en;
  final String ar;
}

class Conversation {
  const Conversation({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.sceneAr,
    required this.lines,
  });

  final String id;
  final String titleAr;
  final String titleEn;
  final String sceneAr;
  final List<ConversationLine> lines;
}

enum PathItemKind { grammar, vocabulary, phonics, conversation }

class PathItem {
  const PathItem(this.kind, this.refId);
  final PathItemKind kind;
  final String refId;
}

class LearningPath {
  const LearningPath({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.cefr,
    required this.descAr,
    required this.color,
    required this.icon,
    required this.items,
  });

  final String id;
  final String titleAr;
  final String titleEn;
  final String cefr;
  final String descAr;
  final Color color;
  final IconData icon;
  final List<PathItem> items;
}
