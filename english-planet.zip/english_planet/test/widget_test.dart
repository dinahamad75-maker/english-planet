import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:english_planet/app.dart';
import 'package:english_planet/state/app_state.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('splash advances to onboarding', (WidgetTester tester) async {
    appState;
    await tester.pumpWidget(const EnglishPlanetApp());
    await tester.pump(const Duration(milliseconds: 400));
    // Splash shows the mascot and app name.
    expect(find.text('English Planet'), findsOneWidget);
    // Splash auto-advances after ~2.1s; consume the timer with fixed pumps
    // (the mascot float animation never settles, so pumpAndSettle cannot be
    // used anywhere in this app).
    await tester.pump(const Duration(milliseconds: 2200));
    await tester.pump(const Duration(milliseconds: 600));
    // Onboarding first page appears.
    expect(find.byType(PageView), findsOneWidget);
  });

  testWidgets('onboarding completes into main shell',
      (WidgetTester tester) async {
    await tester.pumpWidget(const EnglishPlanetApp());
    await tester.pump(const Duration(milliseconds: 400));
    await tester.pump(const Duration(milliseconds: 2200));
    await tester.pump(const Duration(milliseconds: 600));
    // Walk through onboarding pages by tapping the primary button.
    for (int i = 0; i < 3; i++) {
      final Finder next = find.byType(ElevatedButton);
      if (next.evaluate().isEmpty) break;
      await tester.tap(next.last);
      await tester.pump(const Duration(milliseconds: 400));
      await tester.pump(const Duration(milliseconds: 400));
    }
    await tester.pump(const Duration(milliseconds: 600));
    // Main shell bottom navigation should exist now.
    expect(find.byType(NavigationBar), findsOneWidget);
  });
}
