import 'dart:async';

import 'package:flutter/material.dart';

import 'app.dart';
import 'state/app_state.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Show the first frame immediately. Saved progress loads in the
  // background while the splash screen (2.1s) is visible; AppState calls
  // notifyListeners() when loading finishes, so every screen refreshes
  // itself. Blocking runApp on disk I/O can leave the app stuck on a
  // blank white launch screen on devices where the storage plugin is
  // slow to answer.
  runApp(const EnglishPlanetApp());
  unawaited(appState.load().catchError((Object _) {
    // Corrupt or unreadable local data must never block the app;
    // defaults are already in place.
  }));
}
